/**
 * NOXY — Next Studio
 * NXY_CORE: Evento Ready — inicialização e sistemas automáticos
 */

const fs = require('fs');
const path = require('path');
const { ActivityType } = require('discord.js');
const { carregarCache } = require('../../Handler/EmojiFunctions');
const { VerificarPagamento } = require('../../Functions/VerficarPagamento');
const { EntregarPagamentos } = require('../../Functions/AprovarPagamento');
const { VerificarPagamentoRobux } = require('../../Functions/VerificarPagamentoRobux');
const { configuracao } = require('../../DataBaseJson');
const { SincronizarDados } = require('../../Functions/SincronizarDados.js');
const { restart } = require('../../Functions/Restart.js');
const { Varredura } = require('../../Functions/Varredura.js');

module.exports = {
    name: 'ready',

    run: async (client) => {
        console.clear();

        // ─────────────────────────────────────────
        // NXY_CORE — Status rotativo (configurável via painel)
        // ─────────────────────────────────────────
        const statusKeys = ['Status1', 'Status2'];
        let statusIdx = 0;
        setInterval(() => {
            const status = configuracao.get(statusKeys[statusIdx]);
            if (status) client.user.setActivity(status, { type: ActivityType.Playing });
            statusIdx = (statusIdx + 1) % statusKeys.length;
        }, 5000);

        // ─────────────────────────────────────────
        // NXY_CORE — Verificação de servidores
        // Abandona servidores não autorizados (comportamento original preservado)
        // ─────────────────────────────────────────
        if (client.guilds.cache.size > 1) {
            client.guilds.cache.forEach(guild => {
                if (guild.id !== "") guild.leave().catch(() => null);
            });
        }

        // ─────────────────────────────────────────
        // NXY_CORE — Reset de carrinhos ativos ao reiniciar
        // ─────────────────────────────────────────
        const resetCarrinhos = () =>
            fs.writeFileSync(
                path.resolve(__dirname, '../../DataBaseJson/carrinhos.json'),
                '{}'
            );
        resetCarrinhos();

        // ─────────────────────────────────────────
        // NXY_CORE — Sistemas automáticos
        // ─────────────────────────────────────────
        setInterval(() => VerificarPagamento(client), 10000);
        setInterval(() => EntregarPagamentos(client), 14000);
        setInterval(() => VerificarPagamentoRobux(client), 10000);

        restart(client);
        Varredura(client);
        SincronizarDados(client);
        setInterval(() => SincronizarDados(client), 7200000);
        setInterval(() => Varredura(client), 86400000);

        console.log(`\x1b[36m[NOXY]\x1b[0m ${client.user.tag} Online e pronto!`);
        carregarCache();
    }
};
