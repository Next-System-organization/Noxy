const client = require("../../index");
const Discord = require("discord.js")
const { configuracao } = require("../../DataBaseJson");
const { res } = require("../../res");

module.exports = {
    name: 'interactionCreate',

    run: async (interaction, client) => {
        if (interaction.isChatInputCommand()) {

            const cmd = client.slashCommands.get(interaction.commandName);

            if (!cmd) return interaction.reply(`Ocorreu algum erro amigo.`);

            interaction["member"] = interaction.guild.members.cache.get(interaction.user.id);

            
            try {
                const logChannelId = configuracao.get(`ConfigChannels.logscomandos`);
                const logChannel = client.channels.cache.get(logChannelId);
                if (logChannel) {
                    const containerContent = res.main(
                        { type: 10, content: `**Comando Utilizado**` },
                        { type: 14 },
                        { type: 10, content: `> **Usuário:** ${interaction.user}\n> **Comando:** \`/${interaction.commandName}\`\n> **Canal:** ${interaction.channel}` }
                    ).with({});

                    logChannel.send({ content: `Usuário <@${interaction.user.id}> utilizou o comando \`/${interaction.commandName}\``, ...containerContent });
                }
            } catch (error) {}

            cmd.run(client, interaction)

        }

        if (interaction.isMessageContextMenuCommand()) {
            const command = client.slashCommands.get(interaction.commandName);
            if (command) command.run(client, interaction);
        }

        if (interaction.isUserContextMenuCommand()) {
            const command = client.slashCommands.get(interaction.commandName);
            if (command) command.run(client, interaction);
        }
    }
}