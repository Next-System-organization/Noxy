const Discord = require("discord.js")
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require("discord.js")
const { Painel, Gerenciar2, PainelExtensoes } = require("../../Functions/Painel");
const { PainelPermissions, ModalAdicionarPerm, ModalRemoverPerm, HandleAdicionarPerm, HandleRemoverPerm, HandleResetarPerms } = require("../../Functions/gerenciarpermsadm.js");
const { Gerenciar } = require("../../Functions/Gerenciar");
const { configqrcode } = require("../../Functions/QRCode.js");
const { infosauth } = require("../../Functions/infosauth");
const { gerenciarPerms } = require("../../Functions/modUsersPerms");
const { configauth } = require("../../Functions/eCloudConfigs");
const { automatico } = require("../../Functions/automaticos");
const { infoauth } = require("../../Functions/infoauth");
const { ecloud } = require("../../Functions/eCloudConfig");      
const { ConfigRoles } = require("../../Functions/ConfigRoles");
const { EstatisticasNxy } = require("../../index.js");
const { profileuser } = require("../../Functions/profile");
const { misticConfigs } = require("../../Functions/misticpayconfig.js");
const { produtos, configuracao, tickets } = require("../../DataBaseJson");
const { Posicao1 } = require("../../Functions/PosicoesFunction.js");
const { painelTicket, ModalCriarPainelTicket, HandleCriarPainelTicket, PaginaGerenciarPainel } = require("../../Functions/PainelTickets.js");
const { PaginaCategorias, ModalAddFuncaoTicket, HandleAddFuncaoTicket, PaginaRemoverFuncao, HandleRemoverFuncao } = require("../../Functions/TicketCategorias.js");
const { PreviewTicket, AlternarExibicao, HandleDeletarPainel, ModalEditarPainel, HandleEditarPainel, PostarTicket, SincronizarTicket } = require("../../Functions/TicketAcoes.js");
const { SistemaSugestao } = require("../../Functions/sugestao.js");
const { msgbemvindo } = require("../../Functions/MensagemBemVindo");
const { AcoesRepostAutomatics } = require("../../Functions/ConfigRepostAuto.js");
const { CreateMessageTicket, Checkarmensagensticket } = require("../../Functions/CreateMensagemTicket.js");
const { CreateTicket } = require("../../Functions/CreateTicket.js");
const { GerenciarCampos2 } = require("../../Functions/GerenciarCampos.js");
const { moedaConfig } = require("../../Functions/moedaConfig.js");
const { MessageStock } = require("../../Functions/ConfigEstoque.js");
const { auth02api } = require("../../Functions/configurarauth02.js");
const { imapConfigs } = require("../../Functions/configinter.js")
const { painelRobux, painelConfigMensagem, configCanaisRobux, modalConfigValores, modalConfigLimites, handleModalValores, handleModalLimites, modalConfigurarContainer, handleModalConfigurarContainer, visualizarMensagem, enviarMensagemRobux, robuxConfig, mensagemRobux } = require("../../Functions/PainelRobux.js")
const { criarCarrinhoRobux, modalNickRoblox, handleModalNickRoblox, cancelarCompra, atualizarGamepasses, carrinhosRobux, voltarParaGamepasses, mostrarCheckout } = require("../../Functions/CarrinhoRobux.js")
const { irParaPagamentoRobux, copiarPixRobux } = require("../../Functions/PagamentoRobux.js")
const { confirmarEntregaRobux } = require("../../Functions/VerificarPagamentoRobux.js")
const { PainelSorteios, ModalCriarSorteio, PaginaSetarTempo, PaginaEscolherCanal, PaginaGerenciarCargos, EnviarMensagemSorteio, ModalTempoPersonalizado, parseTime, gerarIdSorteio, rerollSorteio, gerarListaParticipantes, atualizarEmbedSorteio, PaginaGerenciarSorteios, PaginaGerenciarSorteioEspecifico, PaginaConfirmarForcarFinalizacao, PaginaConfirmarDescontinuar, ModalAdicionarTempo, descontinuarSorteio, forcarFinalizacao } = require("../../Functions/PainelSorteios.js")
const { sorteios } = require("../../DataBaseJson")
const { res } = require("../../res")
const EventEmitter = require("events");
const emojis = require("../../DataBaseJson/emojis.json");


const Emojis = {
    get: (name) => emojis[name] || ""
};


async function mostrarPaginaProdutos(interaction, page = 0) {
    const { res } = require("../../res");
    const ggg = produtos.fetchAll();
    const ITEMS_PER_PAGE = 25;
    const totalPages = Math.ceil(ggg.length / ITEMS_PER_PAGE);
    
    
    if (page < 0) page = 0;
    if (page >= totalPages) page = totalPages - 1;
    if (totalPages === 0) page = 0;
    
    const startIndex = page * ITEMS_PER_PAGE;
    const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, ggg.length);
    const currentProducts = ggg.slice(startIndex, endIndex);
    
    const options = currentProducts.map(gggg => {
        let desc = gggg?.data?.Config?.desc;
        let aaaaaa;

        if (desc == undefined) {
            desc = "Não definido";
        }
        if (desc && desc.length > 0) {
            aaaaaa = desc.slice(0, 70);
        } else {
            aaaaaa = "Não definido";
        }

        let name = gggg?.data?.Config?.name;
        if (name == undefined) {
            name = "Não definido";
        }

        return {
            label: `${name}`,
            description: `${aaaaaa}`,
            value: gggg.ID,
            emoji: { id: "1178163524443316285" },
        };
    });

    const rowVoltar = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("voltar3")
            .setLabel("Voltar")
            .setEmoji(`1178068047202893869`)
            .setStyle(2)
    );

    if (ggg.length === 0) {
        const containerContent = res.main(
            { type: 10, content: `-# Painel > Sistema de Vendas > Gerenciar Produtos` },
            { type: 14 },
            { type: 10, content: `**Gerenciar Produtos**` },
            { type: 14 },
            { type: 10, content: `${Emojis.get('negative')} Nenhum produto cadastrado ainda.` }
        ).with({
            components: [rowVoltar],
            flags: [64]
        });
        await interaction.update(containerContent);
        return;
    }

    const containerContent = res.main(
        { type: 10, content: `-# Painel > Sistema de Vendas > Gerenciar Produtos` },
        { type: 14 },
        { type: 10, content: `${interaction.user} Qual produto deseja gerenciar?` },
        { type: 14 },
        {
            type: 1,
            components: [{
                type: 3,
                custom_id: "configproduto_page",
                placeholder: `Selecione um produto (Página ${page + 1}/${totalPages})`,
                options: options
            }]
        },
        {
            type: 1,
            components: [
                { type: 2, style: 2, custom_id: `produtos_page_${page - 1}`, emoji: { id: '1460477624206889093' }, disabled: page === 0 },
                { type: 2, style: 2, custom_id: 'disabled_middle', emoji: { id: '1178163524443316285' }, disabled: true },
                { type: 2, style: 2, custom_id: `produtos_page_${page + 1}`, emoji: { id: '1460477653030146089' }, disabled: page >= totalPages - 1 }
            ]
        }
    ).with({
        components: [rowVoltar],
        flags: [64]
    });
    
    await interaction.update(containerContent);
}


module.exports = {
    name: 'interactionCreate',

    run: async (interaction, client) => {

        if (interaction.type == Discord.InteractionType.ModalSubmit) {

            
            if (interaction.customId === 'modal_renomear_ticket') {
                const novoNome = interaction.fields.getTextInputValue('novo_nome_ticket');
                
                try {
                    await interaction.channel.setName(novoNome);
                    await interaction.reply({ content: `${Emojis.get('checker')} | Ticket renomeado para **${novoNome}**!`, ephemeral: true });
                } catch (error) {
                    await interaction.reply({ content: `${Emojis.get('negative')} | Erro ao renomear ticket.`, ephemeral: true });
                }
                return;
            }

            
            if (interaction.customId === 'modal_adicionar_usuario_ticket') {
                const userId = interaction.fields.getTextInputValue('usuario_id_adicionar');
                
                try {
                    const user = await interaction.guild.members.fetch(userId);
                    await interaction.channel.members.add(user.id);
                    await interaction.reply({ content: `${Emojis.get('checker')} | ${user} foi adicionado ao ticket!`, ephemeral: true });
                    await interaction.channel.send({ content: `${Emojis.get('checker')} | ${user} foi adicionado ao ticket por ${interaction.user}.` });
                } catch (error) {
                    await interaction.reply({ content: `${Emojis.get('negative')} | Usuário não encontrado ou erro ao adicionar.`, ephemeral: true });
                }
                return;
            }

            
            if (interaction.customId === 'modal_remover_usuario_ticket') {
                const userId = interaction.fields.getTextInputValue('usuario_id_remover');
                
                try {
                    const user = await interaction.guild.members.fetch(userId);
                    await interaction.channel.members.remove(user.id);
                    await interaction.reply({ content: `${Emojis.get('checker')} | ${user} foi removido do ticket!`, ephemeral: true });
                    await interaction.channel.send({ content: `${Emojis.get('negative')} | ${user} foi removido do ticket por ${interaction.user}.` });
                } catch (error) {
                    await interaction.reply({ content: `${Emojis.get('negative')} | Usuário não encontrado ou erro ao remover.`, ephemeral: true });
                }
                return;
            }

            if (interaction.customId == 'sdaju11111231idsj1233js123dua123') {
                let NOME = interaction.fields.getTextInputValue('tokenMP');
                let PREDESC = interaction.fields.getTextInputValue('tokenMP2');
                let DESC = interaction.fields.getTextInputValue('tokenMP3');
                let BANNER = interaction.fields.getTextInputValue('tokenMP5');
                let EMOJI = interaction.fields.getTextInputValue('tokenMP6');

                NOME = NOME.replace('.', '');
                PREDESC = PREDESC.replace('.', '');

                if (tickets.get(`tickets.funcoes.${NOME}`) !== null) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | Já existe uma função com esse nome!`, ephemeral: true });
                }

                if (NOME.length > 32) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | O nome não pode ter mais de 32 caracteres!`, ephemeral: true });
                } else {
                    tickets.set(`tickets.funcoes.${NOME}.nome`, NOME)
                }

                if (PREDESC.length > 64) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | A pré descrição não pode ter mais de 64 caracteres!`, ephemeral: true });
                } else {
                    tickets.set(`tickets.funcoes.${NOME}.predescricao`, PREDESC)
                }

                if (DESC !== '') {
                    if (DESC.length > 1024) {
                        return interaction.reply({ content: `${Emojis.get('negative')} | A descrição não pode ter mais de 1024 caracteres!`, ephemeral: true });
                    } else {
                        tickets.set(`tickets.funcoes.${NOME}.descricao`, DESC)
                    }
                }

                if (BANNER !== '') {
                    const urlRegex = /^(ftp|http|https):\/\/[^ "]+$/;
                    if (!urlRegex.test(BANNER)) {
                        tickets.set(`tickets.funcoes.${NOME}.banner`, BANNER)
                        return interaction.reply({ message: dd, content: `${Emojis.get('negative')} | Você escolheu incorretamente a URL do banner!`, ephemeral: true });
                    } else {
                        tickets.set(`tickets.funcoes.${NOME}.banner`, BANNER)
                    }
                }

                if (EMOJI !== '') {
                    const emojiRegex = /^<:.+:\d+>$|^<a:.+:\d+>$|^\p{Emoji}$/u;
                    if (!emojiRegex.test(EMOJI)) {
                        return interaction.reply({ content: `${Emojis.get('negative')} | Você escolheu incorretamente o emoji!`, ephemeral: true });
                    } else {
                        tickets.set(`tickets.funcoes.${NOME}.emoji`, EMOJI)
                    }
                }

                await painelTicket(interaction)

                interaction.followUp({ content: `${Emojis.get('checker')} | Função adicionada com sucesso!`, ephemeral: true });




            }

            if (interaction.customId == '0-89du0awd8awdaw8daw') {

                let TITULO = interaction.fields.getTextInputValue('tokenMP');
                let DESC = interaction.fields.getTextInputValue('tokenMP2');
                let BANNER = interaction.fields.getTextInputValue('tokenMP3');
                let COREMBED = interaction.fields.getTextInputValue('tokenMP5');

                if (TITULO.length > 256) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | O título não pode ter mais de 256 caracteres!`, ephemeral: true });
                }
                if (DESC.length > 1024) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | A descrição não pode ter mais de 1024 caracteres!`, ephemeral: true });
                }

                if (COREMBED !== '') {
                    const hexColorRegex = /^#?([0-9A-Fa-f]{6}|[0-9A-Fa-f]{3})$/;
                    if (!hexColorRegex.test(COREMBED)) {
                        
                        return interaction.reply({ content: `${Emojis.get('negative')} Código Hex Color \`${COREMBED}\` inváldo, tente pegar [nesse site.](https://www.google.com/search?q=color+picker&oq=color+picker) `, ephemeral: true });
                    }else{
                        tickets.set(`tickets.aparencia.color`, COREMBED)
                    }
                }



                if (BANNER !== '') {
                    const urlRegex = /^(ftp|http|https):\/\/[^ "]+$/;
                    if (!urlRegex.test(BANNER)) {
                     
                        return interaction.reply({ message: dd, content: `${Emojis.get('negative')} | Você escolheu incorretamente a URL do banner!`, ephemeral: true });
                    }else{
                        tickets.set(`tickets.aparencia.banner`, BANNER)
                    }
                }

                if (TITULO !== '') {
                    tickets.set(`tickets.aparencia.title`, TITULO)
                } else {
                    tickets.delete(`tickets.aparencia.title`)
                }

                if (DESC !== '') {
                    tickets.set(`tickets.aparencia.description`, DESC)
                } else {
                    tickets.delete(`tickets.aparencia.description`)
                }

                await painelTicket(interaction)


            }

      


            if (interaction.customId === 'aslfdjauydvaw769dg7waajnwndjo') {

                let VALOR = interaction.fields.getTextInputValue('tokenMP');
                let CARGO = interaction.fields.getTextInputValue('tokenMP2');


                if (CARGO !== '' && VALOR !== '') {
                    const role = await interaction.guild.roles.fetch(CARGO);

                    if (role === null) {
                        return interaction.reply({ content: `${Emojis.get('negative')} | Você escolheu incorretamente o ID do cargo!`, ephemeral: true });
                    }

                    if (isNaN(VALOR)) {
                        return interaction.reply({ content: `${Emojis.get('negative')} | Você escolheu incorretamente o valor!`, ephemeral: true });
                    }

                    configuracao.set(`posicoes.pos1.role`, CARGO);
                    configuracao.set(`posicoes.pos1.valor`, VALOR);
                } else {
                    configuracao.delete(`posicoes.pos1`);
                }

                await Posicao1(interaction, client)
                

            }

            if (interaction.customId === 'awiohdbawudwdwhduawdnuaw') {

                let VALOR = interaction.fields.getTextInputValue('tokenMP');
                let CARGO = interaction.fields.getTextInputValue('tokenMP2');


                if (CARGO !== '' && VALOR !== '') {
                    const role = await interaction.guild.roles.fetch(CARGO);

                    if (role === null) {
                        return interaction.reply({ content: `${Emojis.get('negative')} | Você escolheu incorretamente o ID do cargo!`, ephemeral: true });
                    }

                    if (isNaN(VALOR)) {
                        return interaction.reply({ content: `${Emojis.get('negative')} | Você escolheu incorretamente o valor!`, ephemeral: true });
                    }

                    configuracao.set(`posicoes.pos2.role`, CARGO);
                    configuracao.set(`posicoes.pos2.valor`, VALOR);
                } else {
                    configuracao.delete(`posicoes.pos2`);
                }

                await Posicao1(interaction, client)
                
            }

            if (interaction.customId === 'uy82819171h172') {

                let VALOR = interaction.fields.getTextInputValue('tokenMP');
                let CARGO = interaction.fields.getTextInputValue('tokenMP2');

                if (CARGO !== '' && VALOR !== '') {
                    const role = await interaction.guild.roles.fetch(CARGO);

                    if (role === null) {
                        return interaction.reply({ content: `${Emojis.get('negative')} | Você escolheu incorretamente o ID do cargo!`, ephemeral: true });
                    }

                    if (isNaN(VALOR)) {
                        return interaction.reply({ content: `${Emojis.get('negative')} | Você escolheu incorretamente o valor!`, ephemeral: true });
                    }

                    configuracao.set(`posicoes.pos3.role`, CARGO);
                    configuracao.set(`posicoes.pos3.valor`, VALOR);
                } else {
                    configuracao.delete(`posicoes.pos3`);
                }

                await Posicao1(interaction, client)
                
            }

            
            if (interaction.customId === 'robux_modal_valores') {
                await handleModalValores(interaction);
            }

            if (interaction.customId === 'robux_modal_limites') {
                await handleModalLimites(interaction);
            }

            
            if (interaction.customId === 'robux_modal_configurar_container') {
                await handleModalConfigurarContainer(interaction);
            }

            
            if (interaction.customId.startsWith('robux_modal_nick_')) {
                const tipo = interaction.customId.replace('robux_modal_nick_', '');
                await handleModalNickRoblox(interaction, tipo);
            }

            
            if (interaction.customId === 'modal_adicionar_perm') {
                await HandleAdicionarPerm(interaction, client);
            }

            
            if (interaction.customId === 'modal_remover_perm') {
                await HandleRemoverPerm(interaction, client);
            }

            
            if (interaction.customId === 'modal_criar_painel_ticket') {
                await HandleCriarPainelTicket(interaction);
            }

            
            if (interaction.customId.startsWith('modal_addfuncao_')) {
                const painelId = interaction.customId.replace('modal_addfuncao_', '');
                await HandleAddFuncaoTicket(interaction, painelId);
            }

            
            if (interaction.customId.startsWith('modal_editar_')) {
                const painelId = interaction.customId.replace('modal_editar_', '');
                await HandleEditarPainel(interaction, painelId);
                return;
            }

            
            if (interaction.customId === 'modal_criar_sorteio') {
                const titulo = interaction.fields.getTextInputValue('sorteio_titulo');
                const descricao = interaction.fields.getTextInputValue('sorteio_descricao');
                const vencedores = interaction.fields.getTextInputValue('sorteio_vencedores');

                if (isNaN(vencedores) || parseInt(vencedores) < 1) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | O número de vencedores deve ser um número válido maior que 0!`, ephemeral: true });
                }

                const sorteioId = gerarIdSorteio();
                
                sorteios.set(sorteioId, {
                    id: sorteioId,
                    titulo: titulo,
                    descricao: descricao,
                    vencedores: parseInt(vencedores),
                    criador: interaction.user.id,
                    criadoEm: Date.now(),
                    status: "configurando",
                    participantes: []
                });

                await PaginaSetarTempo(interaction, sorteioId);
            }

            
            if (interaction.customId.startsWith('modal_tempo_personalizado_')) {
                const sorteioId = interaction.customId.replace('modal_tempo_personalizado_', '');
                const tempoStr = interaction.fields.getTextInputValue('tempo_personalizado');
                
                const tempoMs = parseTime(tempoStr);
                
                if (tempoMs <= 0) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | Formato de tempo inválido! Use: m = minutos, h = horas, d = dias\nExemplos: 30m, 2h, 1d, 1d 2h 30m`, ephemeral: true });
                }

                const maxTempo = 30 * 24 * 60 * 60 * 1000; 
                if (tempoMs > maxTempo) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | O tempo máximo é de 30 dias!`, ephemeral: true });
                }

                sorteios.set(`${sorteioId}.duracao`, tempoMs);

                await PaginaEscolherCanal(interaction, sorteioId);
            }

            
            if (interaction.customId.startsWith('modal_addtempo_')) {
                const sorteioId = interaction.customId.replace('modal_addtempo_', '');
                const tempoStr = interaction.fields.getTextInputValue('tempo_adicionar');
                
                const tempoMs = parseTime(tempoStr);
                
                if (tempoMs <= 0) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | Formato de tempo inválido! Use: m = minutos, h = horas, d = dias\nExemplos: 30m, 2h, 1d`, ephemeral: true });
                }

                const sorteioData = sorteios.get(sorteioId);
                if (!sorteioData) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | Sorteio não encontrado!`, ephemeral: true });
                }

                const novoFinalizaEm = sorteioData.finalizaEm + tempoMs;
                sorteios.set(`${sorteioId}.finalizaEm`, novoFinalizaEm);
                sorteios.set(`${sorteioId}.duracao`, sorteioData.duracao + tempoMs);

                await interaction.reply({ content: `${Emojis.get('checker')} | Tempo adicionado! Nova finalização: <t:${Math.floor(novoFinalizaEm / 1000)}:R>`, ephemeral: true });
            }

            
            if (interaction.customId === 'modal_stock_titulo') {
                const valor = interaction.fields.getTextInputValue('valor');
                const embedConfig = configuracao.get('solicitarStock.embed') || {};
                embedConfig.titulo = valor;
                configuracao.set('solicitarStock.embed', embedConfig);
                const { PaginaConfigurarEmbed } = require("../../Functions/PainelSolicitarStock.js");
                await PaginaConfigurarEmbed(interaction, client);
            }

            if (interaction.customId === 'modal_stock_descricao') {
                const valor = interaction.fields.getTextInputValue('valor');
                const embedConfig = configuracao.get('solicitarStock.embed') || {};
                embedConfig.descricao = valor;
                configuracao.set('solicitarStock.embed', embedConfig);
                const { PaginaConfigurarEmbed } = require("../../Functions/PainelSolicitarStock.js");
                await PaginaConfigurarEmbed(interaction, client);
            }

            if (interaction.customId === 'modal_stock_cor') {
                const valor = interaction.fields.getTextInputValue('valor');
                if (!/^#?([0-9A-Fa-f]{6}|[0-9A-Fa-f]{3})$/.test(valor)) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | Cor inválida! Use formato hex (ex: #5865F2)`, ephemeral: true });
                }
                const embedConfig = configuracao.get('solicitarStock.embed') || {};
                embedConfig.cor = valor.startsWith('#') ? valor : `#${valor}`;
                configuracao.set('solicitarStock.embed', embedConfig);
                const { PaginaConfigurarEmbed } = require("../../Functions/PainelSolicitarStock.js");
                await PaginaConfigurarEmbed(interaction, client);
            }

            if (interaction.customId === 'modal_stock_imagem') {
                const valor = interaction.fields.getTextInputValue('valor');
                const embedConfig = configuracao.get('solicitarStock.embed') || {};
                embedConfig.imagem = valor || null;
                configuracao.set('solicitarStock.embed', embedConfig);
                const { PaginaConfigurarEmbed } = require("../../Functions/PainelSolicitarStock.js");
                await PaginaConfigurarEmbed(interaction, client);
            }

            if (interaction.customId === 'modal_stock_thumbnail') {
                const valor = interaction.fields.getTextInputValue('valor');
                const embedConfig = configuracao.get('solicitarStock.embed') || {};
                embedConfig.thumbnail = valor || null;
                configuracao.set('solicitarStock.embed', embedConfig);
                const { PaginaConfigurarEmbed } = require("../../Functions/PainelSolicitarStock.js");
                await PaginaConfigurarEmbed(interaction, client);
            }

            
            if (interaction.customId === 'modal_stock_botao_msg') {
                const valor = interaction.fields.getTextInputValue('valor');
                const botaoConfig = configuracao.get('solicitarStock.botao') || {};
                botaoConfig.mensagem = valor;
                configuracao.set('solicitarStock.botao', botaoConfig);
                const { PaginaConfigurarEmbed } = require("../../Functions/PainelSolicitarStock.js");
                await PaginaConfigurarEmbed(interaction, client);
            }

            if (interaction.customId === 'modal_stock_botao_emoji') {
                const valor = interaction.fields.getTextInputValue('valor');
                const botaoConfig = configuracao.get('solicitarStock.botao') || {};
                botaoConfig.emoji = valor || null;
                configuracao.set('solicitarStock.botao', botaoConfig);
                const { PaginaConfigurarEmbed } = require("../../Functions/PainelSolicitarStock.js");
                await PaginaConfigurarEmbed(interaction, client);
            }

            if (interaction.customId === 'modal_stock_botao_cor') {
                const valor = interaction.fields.getTextInputValue('valor');
                if (!['1', '2', '3', '4'].includes(valor)) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | Cor inválida! Use 1=Azul, 2=Cinza, 3=Verde, 4=Vermelho`, ephemeral: true });
                }
                const botaoConfig = configuracao.get('solicitarStock.botao') || {};
                botaoConfig.cor = parseInt(valor);
                configuracao.set('solicitarStock.botao', botaoConfig);
                const { PaginaConfigurarEmbed } = require("../../Functions/PainelSolicitarStock.js");
                await PaginaConfigurarEmbed(interaction, client);
            }

            
            if (interaction.customId === 'modal_solicitar_estoque') {
                const { EnviarLogSolicitacao } = require("../../Functions/PainelSolicitarStock.js");
                await EnviarLogSolicitacao(interaction, client);
            }

        }

        if (interaction.isAutocomplete()) {
            if (interaction.commandName === 'manage_item') {
                const nomeDigitado = interaction.options.getFocused().toLowerCase();
                const produtosFiltrados = produtos.filter(produto => produto.ID.toLowerCase().includes(nomeDigitado));
                const produtosSelecionados = produtosFiltrados.slice(0, 25);
        
                const config = produtosSelecionados.flatMap(produto => {
                    
                    if (produto.data && produto.data.Campos) {
                        const matchingFields = produto.data.Campos.filter(campo =>
                            campo.Nome.toLowerCase().includes(nomeDigitado)
                        );
        
                        return matchingFields.map(campo => ({
                            name: `🧵 ${campo.Nome}`,
                            value: `${produto.ID}_${campo.Nome}`,
                        }));
                    } else {
                        
                        return [];
                    }
                });
        
                
                const response = config.length > 25 ? config.slice(0, 25) : config;
        
                interaction.respond(response);
            }        

            if (interaction.commandName === 'manage_stock') {
                const nomeDigitado = interaction.options.getFocused().toLowerCase();
                const produtosFiltrados = produtos.filter(produto => produto.ID.toLowerCase().includes(nomeDigitado));
                const produtosSelecionados = produtosFiltrados.slice(0, 25);
            
                const response = produtosSelecionados.map(produto => {
                const name = produto.data.Config ? produto.data.Config.name : "Nome Não Disponível";
            
                    
                    const option = {
                        name: `🧵 ${name}`,
                        value: produto.ID
                    };
            
                    
                    if (JSON.stringify(option).length > 100) {
                        
                        option.name = option.name.substring(0, 90) + '...'; 
                        option.value = option.value.substring(0, 90) + '...'; 
                    }
            
                    return option;
                });
                
                
                interaction.respond(response.length > 0 ? response : [{ name: 'Nenhum produto registrado foi encontrado', value: 'nada' }]);
            }
            


            if (interaction.commandName == 'manage_product') {
                var nomeDigitado = interaction.options.getFocused().toLowerCase();
                var produtosFiltrados = produtos.filter(x => x.ID.toLowerCase().includes(nomeDigitado));
                var produtosSelecionados = produtosFiltrados.slice(0, 25);

                const config = produtosSelecionados.map(x => {
                    const name = x.data.Config ? x.data.Config.name : "Nome Não Disponível";
                    return {
                        name: `🧵 ${name}`,
                        value: `${x.ID}`
                    };
                });
                
                interaction.respond(!config.length ? [{ name: `${Emojis.get('negative')} Nenhum produto registrado foi encontrado`, value: `nada` }] : config);

            }
        }

        
        if (interaction.isButton() && interaction.customId.startsWith('gerar_transcript_')) {
            try {
                
                await interaction.deferUpdate();
                
                const transcriptId = interaction.customId.replace('gerar_transcript_', '');
                const { transcript } = require("../../DataBaseJson");
                const transcriptData = transcript.get(transcriptId);

                if (!transcriptData) {
                    return interaction.followUp({ content: `${Emojis.get('negative')} | Transcript não encontrado.` });
                }

                
                let transcriptText = `═══════════════════════════════════════\n`;
                transcriptText += `       TRANSCRIPT - ${transcriptData.guildName}\n`;
                transcriptText += `═══════════════════════════════════════\n\n`;
                transcriptText += `Categoria: ${transcriptData.categoria}\n`;
                transcriptText += `Fechado por: ${transcriptData.fechadoPor}\n`;
                transcriptText += `Data: ${transcriptData.fechadoEm}\n`;
                transcriptText += `Total de mensagens: ${transcriptData.mensagens.length}\n\n`;
                transcriptText += `───────────────────────────────────────\n`;
                transcriptText += `                MENSAGENS\n`;
                transcriptText += `───────────────────────────────────────\n\n`;

                for (const msg of transcriptData.mensagens) {
                    transcriptText += `[${msg.timestamp}] ${msg.author}:\n${msg.content}\n\n`;
                }

                transcriptText += `═══════════════════════════════════════\n`;
                transcriptText += `           FIM DO TRANSCRIPT\n`;
                transcriptText += `═══════════════════════════════════════`;

                
                const buffer = Buffer.from(transcriptText, 'utf-8');

                
                await interaction.followUp({ 
                    content: `${Emojis.get('checker')} | Aqui está o transcript do seu atendimento:`,
                    files: [{ attachment: buffer, name: `transcript_${transcriptData.categoria}.txt` }]
                });

                
                transcript.delete(transcriptId);

                
                const disabledContainer = res.main(
                    { type: 10, content: `# ${Emojis.get('_trash_emoji')} Ticket Fechado` },
                    { type: 14 },
                    { type: 10, content: `> Seu ticket de **${transcriptData.categoria}** foi encerrado.` },
                    { type: 14 },
                    { type: 10, content: `**Fechado por**\n${transcriptData.fechadoPor}` },
                    { type: 10, content: `**Data**\n${transcriptData.fechadoEm}` },
                    { type: 14 },
                    { type: 10, content: `-# Transcript já foi gerado.` },
                    { type: 1, components: [{ type: 2, style: 2, label: 'Transcript Gerado', custom_id: 'transcript_usado', emoji: { id: '1384035207598051431' }, disabled: true }] }
                );

                await interaction.message.edit(disabledContainer);
            } catch (error) {
                console.error('Erro ao gerar transcript:', error);
                try {
                    await interaction.followUp({ content: `${Emojis.get('negative')} | Erro ao gerar transcript.` });
                } catch {}
            }
            return;
        }

        let valorticket
        if (interaction.isButton() && interaction.customId.startsWith('AbrirTicket::')) {
            
            const parts = interaction.customId.split('::');
            const painelId = parts[1];
            const funcaoId = parts[2];
            
            console.log(`[Ticket] Abrindo ticket - PainelId: ${painelId}, FuncaoId: ${funcaoId}`);
            await CreateTicket(interaction, painelId, funcaoId).catch(err => {
                console.error('[Ticket] Erro ao criar ticket:', err);
                interaction.reply({ content: `❌ | Erro ao criar ticket: ${err.message}`, ephemeral: true }).catch(() => {});
            });
        } else if (interaction.isButton() && interaction.customId.startsWith('AbrirTicket_')) {
            
            const fullId = interaction.customId.replace('AbrirTicket_', '');
            
            const lastUnderscoreIndex = fullId.lastIndexOf('_');
            const funcaoId = fullId.substring(lastUnderscoreIndex + 1);
            const painelId = fullId.substring(0, lastUnderscoreIndex);
            
            console.log(`[Ticket] Abrindo ticket (formato antigo) - PainelId: ${painelId}, FuncaoId: ${funcaoId}`);
            await CreateTicket(interaction, painelId, funcaoId).catch(err => {
                console.error('[Ticket] Erro ao criar ticket:', err);
                interaction.reply({ content: `❌ | Erro ao criar ticket: ${err.message}`, ephemeral: true }).catch(() => {});
            });
        } else if (interaction.isSelectMenu() && interaction.customId === 'abrirticket') {
            valorticket = interaction.values[0]
            
            await CreateTicket(interaction, null, valorticket).catch(err => {
                console.error('[Ticket] Erro ao criar ticket:', err);
                interaction.reply({ content: `❌ | Erro ao criar ticket: ${err.message}`, ephemeral: true }).catch(() => {});
            });
        } else if (interaction.isSelectMenu() && interaction.customId.startsWith('ticket_abrir_select_')) {
            
            const selectedValue = interaction.values[0];
            
            if (selectedValue.includes('::')) {
                
                const parts = selectedValue.split('::');
                const painelId = parts[1];
                const funcaoId = parts[2];
                
                console.log(`[Ticket] Abrindo ticket via select - PainelId: ${painelId}, FuncaoId: ${funcaoId}`);
                await CreateTicket(interaction, painelId, funcaoId).catch(err => {
                    console.error('[Ticket] Erro ao criar ticket:', err);
                    interaction.reply({ content: `❌ | Erro ao criar ticket: ${err.message}`, ephemeral: true }).catch(() => {});
                });
            } else {
                
                const fullId = selectedValue.replace('abrirticket_', '');
                const lastUnderscoreIndex = fullId.lastIndexOf('_');
                const funcaoId = fullId.substring(lastUnderscoreIndex + 1);
                const painelId = fullId.substring(0, lastUnderscoreIndex);
                
                console.log(`[Ticket] Abrindo ticket via select (formato antigo) - PainelId: ${painelId}, FuncaoId: ${funcaoId}`);
                await CreateTicket(interaction, painelId, funcaoId).catch(err => {
                    console.error('[Ticket] Erro ao criar ticket:', err);
                    interaction.reply({ content: `❌ | Erro ao criar ticket: ${err.message}`, ephemeral: true }).catch(() => {});
                });
            }
        }

        if (interaction.isSelectMenu()) {

            
            if (interaction.customId === 'staff_acoes_ticket') {
                const acao = interaction.values[0];

                if (acao === 'assumir_ticket') {
                    let ticketId = interaction.channel.id;
                    const { Temporario } = require("../../DataBaseJson");
                    
                    if (Temporario.get(`ticket_assumido_${ticketId}`)) {
                        const staffId = Temporario.get(`ticket_assumido_${ticketId}`);
                        return interaction.update({ content: `${Emojis.get('negative')} | Este ticket já foi assumido por <@${staffId}>.`, components: [] });
                    }

                    const staffMember = interaction.member;
                    
                    
                    let ownerId = Temporario.get(`ticket_owner_${ticketId}`);
                    if (!ownerId) {
                        const ultimoIndice = interaction.channel.name.lastIndexOf('・');
                        ownerId = interaction.channel.name.slice(ultimoIndice + 1);
                    }

                    
                    if (!ownerId || !/^\d+$/.test(ownerId)) {
                        return interaction.update({ content: `${Emojis.get('negative')} | Não foi possível identificar o dono do ticket.`, components: [] });
                    }

                    try {
                        const owner = await interaction.guild.members.fetch(ownerId);

                        Temporario.set(`ticket_assumido_${ticketId}`, staffMember.id);

                        const confirmationEmbed = new EmbedBuilder()
                            .setColor('#2b2d31')
                            .setDescription(`${Emojis.get('checker')} | Olá <@!${ownerId}>, Seu Ticket foi Assumido por ${staffMember}.`);

                        const buttonRow = new ActionRowBuilder().addComponents(
                            new ButtonBuilder()
                                .setLabel('Ir para o Ticket')
                                .setStyle(5)
                                .setURL(`https://discord.com/channels/${interaction.guild.id}/${interaction.channel.id}`)
                        );

                        try {
                            await owner.send({ embeds: [confirmationEmbed], components: [buttonRow] });
                        } catch {}

                        await interaction.update({ content: `${Emojis.get('checker')} | Ticket assumido com sucesso!`, components: [] });
                        await interaction.channel.send({ content: `${Emojis.get('checker')} | Ticket assumido por ${staffMember}!` });
                    } catch (error) {
                        console.error("Erro ao assumir ticket:", error);
                        await interaction.update({ content: `${Emojis.get('negative')} | Erro ao assumir ticket.`, components: [] });
                    }
                    return;
                }

                if (acao === 'renomear_ticket') {
                    const modal = new ModalBuilder()
                        .setCustomId('modal_renomear_ticket')
                        .setTitle('Renomear Ticket')
                        .addComponents(
                            new ActionRowBuilder().addComponents(
                                new TextInputBuilder()
                                    .setCustomId('novo_nome_ticket')
                                    .setLabel('Novo nome do ticket')
                                    .setPlaceholder('Digite o novo nome...')
                                    .setStyle(TextInputStyle.Short)
                                    .setMaxLength(100)
                                    .setRequired(true)
                            )
                        );
                    await interaction.showModal(modal);
                    return;
                }

                if (acao === 'adicionar_usuario') {
                    const modal = new ModalBuilder()
                        .setCustomId('modal_adicionar_usuario_ticket')
                        .setTitle('Adicionar Usuário')
                        .addComponents(
                            new ActionRowBuilder().addComponents(
                                new TextInputBuilder()
                                    .setCustomId('usuario_id_adicionar')
                                    .setLabel('ID do usuário')
                                    .setPlaceholder('Digite o ID do usuário para adicionar...')
                                    .setStyle(TextInputStyle.Short)
                                    .setRequired(true)
                            )
                        );
                    await interaction.showModal(modal);
                    return;
                }

                if (acao === 'remover_usuario') {
                    const modal = new ModalBuilder()
                        .setCustomId('modal_remover_usuario_ticket')
                        .setTitle('Remover Usuário')
                        .addComponents(
                            new ActionRowBuilder().addComponents(
                                new TextInputBuilder()
                                    .setCustomId('usuario_id_remover')
                                    .setLabel('ID do usuário')
                                    .setPlaceholder('Digite o ID do usuário para remover...')
                                    .setStyle(TextInputStyle.Short)
                                    .setRequired(true)
                            )
                        );
                    await interaction.showModal(modal);
                    return;
                }
            }

            
            if (interaction.customId === 'ticket_selecionar_painel') {
                const painelId = interaction.values[0];
                if (painelId !== 'none') {
                    await PaginaGerenciarPainel(interaction, painelId);
                }
                return;
            }

            
            if (interaction.customId === 'ticket_acoes_select') {
                const selectedValue = interaction.values[0];
                const [acao, ...painelIdParts] = selectedValue.split('_');
                const painelId = painelIdParts.join('_');

                if (acao === 'editar') {
                    await ModalEditarPainel(interaction, painelId);
                } else if (acao === 'categorias') {
                    await PaginaCategorias(interaction, painelId);
                } else if (acao === 'exibicao') {
                    await AlternarExibicao(interaction, painelId);
                } else if (acao === 'apagar') {
                    await HandleDeletarPainel(interaction, painelId);
                } else if (acao === 'enviar') {
                    const selectChannel = new Discord.ChannelSelectMenuBuilder()
                        .setCustomId(`ticket_channel_postar_${painelId}`)
                        .setPlaceholder('Selecione o canal para postar')
                        .setChannelTypes(Discord.ChannelType.GuildText);
                    const row = new ActionRowBuilder().addComponents(selectChannel);
                    await interaction.reply({ content: `${Emojis.get('info')} | Selecione o canal:`, components: [row], ephemeral: true });
                } else if (acao === 'sincronizar') {
                    await SincronizarTicket(interaction, painelId, client);
                }
                return;
            }

            
            if (interaction.customId === 'ticket_select_remfuncao') {
                const [painelId, funcaoId] = interaction.values[0].split('_').slice(-2);
                const fullPainelId = interaction.values[0].replace(`_${funcaoId}`, '');
                await HandleRemoverFuncao(interaction, fullPainelId, funcaoId);
                return;
            }

            
            if (interaction.customId === 'configproduto_page') {
                const { GerenciarProduto } = require("../../Functions/CreateProduto");
                GerenciarProduto(interaction, 2, interaction.values[0]);
                return;
            }

            
            if (interaction.customId == 'gerenciar_produtos_menu') {
                const selectedValue = interaction.values[0];
                
                
                if (selectedValue === 'criarrrr') {
                    const modalaAA = new ModalBuilder()
                        .setCustomId('sdaju11111idsjjsdua')
                        .setTitle(`Criação`);

                    const newnameboteN = new TextInputBuilder()
                        .setCustomId('tokenMP')
                        .setLabel(`NOME`)
                        .setPlaceholder(`Insira o nome do seu produto`)
                        .setStyle(TextInputStyle.Short)
                        .setRequired(true)

                    const newnameboteN2 = new TextInputBuilder()
                        .setCustomId('tokenMP2')
                        .setLabel(`DESCRIÇÃO`)
                        .setPlaceholder(`Insira uma descrição para seu produto`)
                        .setStyle(TextInputStyle.Paragraph)
                        .setRequired(true)
                        .setMaxLength(1024)

                    const newnameboteN4 = new TextInputBuilder()
                        .setCustomId('tokenMP3')
                        .setLabel(`ENTREGA AUTOMÁTICA?`)
                        .setPlaceholder(`Digite "sim" ou "não"`)
                        .setStyle(TextInputStyle.Short)
                        .setMaxLength(3)
                        .setRequired(true)

                    const newnameboteN5 = new TextInputBuilder()
                        .setCustomId('tokenMP4')
                        .setLabel(`ICONE (OPCIONAL)`)
                        .setPlaceholder(`Insira uma URL de uma imagem ou gif`)
                        .setStyle(TextInputStyle.Short)
                        .setRequired(false)

                    const newnameboteN6 = new TextInputBuilder()
                        .setCustomId('tokenMP5')
                        .setLabel(`BANNER (OPCIONAL)`)
                        .setPlaceholder(`Insira uma URL de uma imagem ou gif`)
                        .setStyle(TextInputStyle.Short)
                        .setRequired(false)

                    const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                    const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);
                    const firstActionRow5 = new ActionRowBuilder().addComponents(newnameboteN4);
                    const firstActionRow6 = new ActionRowBuilder().addComponents(newnameboteN5);
                    const firstActionRow7 = new ActionRowBuilder().addComponents(newnameboteN6);

                    modalaAA.addComponents(firstActionRow3, firstActionRow4, firstActionRow5, firstActionRow6, firstActionRow7);
                    await interaction.showModal(modalaAA);
                }
                
                if (selectedValue === 'gerenciarotemae') {
                    await mostrarPaginaProdutos(interaction, 0);
                }
                
                if (selectedValue === 'gerenciarposicao') {
                    Posicao1(interaction, client);
                }
                
                if (selectedValue === 'painel-solicitar-stock') {
                    const { PainelSolicitarStock } = require("../../Functions/PainelSolicitarStock.js");
                    PainelSolicitarStock(interaction, client);
                }
                
                if (selectedValue === 'altMoeda') {
                    await interaction.update({ content: `${Emojis.get('loading')} Carregando...`, embeds: [], components: [] });
                    moedaConfig(interaction, client);
                }
                
                if (selectedValue === 'instruçoes081') {
                    await interaction.reply({ content: `${Emojis.get('negative')} Esta função ainda está em desenvolvimento.`, ephemeral: true });
                }

                if (selectedValue === 'sistemasaldo') {
                    await interaction.reply({ content: `${Emojis.get('negative')} Esta função ainda está em desenvolvimento.`, ephemeral: true });
                }

                if (selectedValue === 'sistemaafiliado') {
                    await interaction.reply({ content: `${Emojis.get('negative')} Esta função ainda está em desenvolvimento.`, ephemeral: true });
                }
            }

            if(interaction.customId == 'asdihadbhawhdwhdaw'){


                const campo = interaction.values[0].split('_')[0]
                const produto = interaction.values[0].split('_')[1]


                GerenciarCampos2(interaction, campo, produto, true)

            }

            if(interaction.customId == 'stockhasdhvsudasd'){

                const campo = interaction.values[0].split('_')[0]
                const produto = interaction.values[0].split('_')[1]

                MessageStock(interaction, 1, produto, campo, true)


            }

            if (interaction.customId == 'deletarticketsfunction') {
                const valordelete = interaction.values
                for (const iterator of valordelete) {
                    tickets.delete(`tickets.funcoes.${iterator}`)
                }
                painelTicket(interaction)
            }

            
            if (interaction.customId === 'robux_status_select') {
                const selectedValue = interaction.values[0];
                
                if (selectedValue === 'ativar_robux') {
                    robuxConfig.set(`config.status`, true);
                    await painelRobux(interaction);
                    interaction.followUp({ content: `${Emojis.get('checker')} | Sistema de Robux ativado com sucesso!`, ephemeral: true });
                }
                
                if (selectedValue === 'desativar_robux') {
                    robuxConfig.set(`config.status`, false);
                    await painelRobux(interaction);
                    interaction.followUp({ content: `${Emojis.get('checker')} | Sistema de Robux desativado com sucesso!`, ephemeral: true });
                }

                if (selectedValue === 'ativar_gamepass') {
                    robuxConfig.set(`config.statusGamepass`, true);
                    await painelRobux(interaction);
                    interaction.followUp({ content: `${Emojis.get('checker')} | Sistema de Gamepass ativado com sucesso!`, ephemeral: true });
                }
                
                if (selectedValue === 'desativar_gamepass') {
                    robuxConfig.set(`config.statusGamepass`, false);
                    await painelRobux(interaction);
                    interaction.followUp({ content: `${Emojis.get('checker')} | Sistema de Gamepass desativado com sucesso!`, ephemeral: true });
                }
            }

            
            if (interaction.customId === 'robux_preview_select') {
                await interaction.reply({ content: `${Emojis.get('info') || 'ℹ️'} | Você está no **modo preview**! Esta é apenas uma visualização da mensagem.`, ephemeral: true });
            }

            
            if (interaction.customId === 'robux_comprar_select') {
                const selectedValue = interaction.values[0];
                
                try {
                    const originalMessage = interaction.message;
                    const originalComponents = originalMessage.components.map(row => {
                        const newRow = ActionRowBuilder.from(row);
                        newRow.components = row.components.map(comp => {
                            if (comp.type === 3 && comp.customId === 'robux_comprar_select') {
                                
                                return { ...comp.data, placeholder: "Escolha uma opção para solicitar o seu pedido" };
                            }
                            return comp;
                        });
                        return newRow;
                    });
                    await interaction.message.edit({ components: originalMessage.components }).catch(() => {});
                } catch (e) {}
                await criarCarrinhoRobux(interaction, selectedValue, client);
            }

            
            if (interaction.customId === 'robux_select_gamepass') {
                const [gamepassId, price] = interaction.values[0].split('_');
                await mostrarCheckout(interaction, gamepassId, parseInt(price));
            }

            
            if (interaction.customId.startsWith('sorteio_select_tempo_')) {
                const sorteioId = interaction.customId.replace('sorteio_select_tempo_', '');
                const tempoSelecionado = interaction.values[0];
                
                const tempoMs = parseTime(tempoSelecionado);
                
                sorteios.set(`${sorteioId}.duracao`, tempoMs);

                await PaginaEscolherCanal(interaction, sorteioId);
            }

            
            if (interaction.customId === 'gerenciar_sorteio_select') {
                const sorteioId = interaction.values[0];
                await PaginaGerenciarSorteioEspecifico(interaction, sorteioId, client);
            }

            
            if (interaction.customId === 'stock_select_embed') {
                const valor = interaction.values[0];
                const { ModalTituloEmbed, ModalDescricaoEmbed, ModalCorEmbed, ModalImagemEmbed, ModalThumbnailEmbed } = require("../../Functions/PainelSolicitarStock.js");
                
                if (valor === 'titulo') await ModalTituloEmbed(interaction);
                else if (valor === 'descricao') await ModalDescricaoEmbed(interaction);
                else if (valor === 'cor') await ModalCorEmbed(interaction);
                else if (valor === 'imagem') await ModalImagemEmbed(interaction);
                else if (valor === 'thumbnail') await ModalThumbnailEmbed(interaction);
            }

            
            if (interaction.customId === 'stock_select_botao') {
                const valor = interaction.values[0];
                const { ModalMensagemBotao, ModalEmojiBotao, ModalCorBotao } = require("../../Functions/PainelSolicitarStock.js");
                
                if (valor === 'mensagem') await ModalMensagemBotao(interaction);
                else if (valor === 'emoji') await ModalEmojiBotao(interaction);
                else if (valor === 'cor') await ModalCorBotao(interaction);
            }

            
            if (interaction.customId === 'robux_select_canal') {
                const selectedValue = interaction.values[0];
                
                const Discord = require("discord.js");
                let channelType = Discord.ChannelType.GuildText;
                let placeholder = 'Selecione um canal';
                let configKey = '';

                if (selectedValue === 'canal_iniciadas') {
                    configKey = 'iniciadas';
                    placeholder = 'Selecione o canal de compras iniciadas';
                } else if (selectedValue === 'canal_canceladas') {
                    configKey = 'canceladas';
                    placeholder = 'Selecione o canal de compras canceladas';
                } else if (selectedValue === 'canal_aprovadas') {
                    configKey = 'aprovadas';
                    placeholder = 'Selecione o canal de compras aprovadas';
                } else if (selectedValue === 'canal_publicas') {
                    configKey = 'publicas';
                    placeholder = 'Selecione o canal de compras públicas';
                } else if (selectedValue === 'categoria_carrinhos') {
                    configKey = 'categoriaCarrinhos';
                    placeholder = 'Selecione a categoria de carrinhos';
                    channelType = Discord.ChannelType.GuildCategory;
                }

                const selectChannel = new Discord.ChannelSelectMenuBuilder()
                    .setCustomId(`robux_channel_select_${configKey}`)
                    .setPlaceholder(placeholder)
                    .setChannelTypes(channelType);

                const row = new ActionRowBuilder().addComponents(selectChannel);

                await interaction.reply({ 
                    content: `${Emojis.get('info')} | Selecione o canal desejado:`, 
                    components: [row], 
                    ephemeral: true 
                });
            }

            
            if (interaction.customId === 'select_acoes_automaticas') {
                const selectedValue = interaction.values[0];
                const { res } = require("../../res");
                
                
                if (selectedValue === 'configMensagensAuto') {
                    const { painelPrincipal } = require("../../Eventos/Sistemas Automaticos/mensagemconfig.js");
                    await painelPrincipal(interaction);
                    return;
                }
                
                
                if (selectedValue === 'monitorfeedbacks') {
                    await interaction.reply({ 
                        content: `${Emojis.get('negative')} A função **Monitorador de Feedbacks** está em desenvolvimento.`, 
                        ephemeral: true 
                    });
                    return;
                }

                
                if (selectedValue === 'sistemasugestoes') {
                    const { PainelSistemaSugestoes } = require("../../Functions/SistemaSugestoes.js");
                    PainelSistemaSugestoes(interaction, client);
                    return;
                }
                
                
                if (selectedValue === 'automaticRepostar') {
                    AcoesRepostAutomatics(interaction, client);
                    return;
                }
                
                
                if (selectedValue === 'configlock') {
                    const automaticosPath = require('path').resolve(__dirname, '../../DataBaseJson/autolock.json');
                    const fs = require('fs');
                    
                    let automaticos = {};
                    if (fs.existsSync(automaticosPath)) {
                        automaticos = JSON.parse(fs.readFileSync(automaticosPath));
                    }
                    
                    const guildId = interaction.guild.id;
                    const config = automaticos[guildId] || {};

                    let channelNames = config.channels
                        ? config.channels.map(id => `<#${id}>`).join(', ')
                        : '*Não configurado*';

                    const rowVoltar = new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setCustomId("voltarautomaticos")
                            .setEmoji(`${Emojis.get('_back_emoji')}`)
                            .setLabel('Voltar')
                            .setStyle(2)
                    );

                    const containerContent = res.main(
                        { type: 10, content: `-# Painel > Ações Automáticas > Lock Automático` },
                        { type: 14 },
                        { type: 10, content: `**Configuração de Lock Automático**\n\n> Bloqueie e desbloqueie canais automaticamente em horários específicos.` },
                        { type: 14 },
                        { type: 10, content: `**Configurações Atuais:**\n> **Horário de Bloqueio:** \`${config.abrir || 'Não configurado'}\`\n> **Horário de Desbloqueio:** \`${config.fechar || 'Não configurado'}\`\n> **Canais:** ${channelNames}` },
                        { type: 14 },
                        {
                            type: 1,
                            components: [
                                {
                                    type: 2,
                                    style: 1,
                                    label: "Modificar",
                                    emoji: { id: "1236318155056349224" },
                                    custom_id: "modifyConfig"
                                },
                                {
                                    type: 2,
                                    style: 4,
                                    label: "Desativar",
                                    emoji: { id: "1178076767567757312" },
                                    custom_id: "disableConfig"
                                }
                            ]
                        }
                    ).with({
                        components: [rowVoltar],
                        flags: [64]
                    });

                    await interaction.update(containerContent);
                    return;
                }
            }



            





        }


        if (interaction.isChannelSelectMenu()) {

            if (interaction.customId == 'canalpostarticket') {
                await interaction.reply({ content: `${Emojis.get('loading')} | Aguarde estamos criando sua mensagem!`, ephemeral: true });
                await CreateMessageTicket(interaction, interaction.values[0], client)
                interaction.editReply({ content: `${Emojis.get('checker')} | Mensagem criada com sucesso!`, ephemeral: true });
            }

            
            if (interaction.customId.startsWith('robux_channel_select_')) {
                const configKey = interaction.customId.replace('robux_channel_select_', '');
                const channelId = interaction.values[0];

                robuxConfig.set(`config.canais.${configKey}`, channelId);
                
                await interaction.update({ 
                    content: `${Emojis.get('checker')} | Canal configurado com sucesso!`, 
                    components: [] 
                });
            }

            
            if (interaction.customId === 'robux_channel_enviar_mensagem') {
                const channelId = interaction.values[0];
                await interaction.update({ content: `${Emojis.get('loading')} | Enviando mensagem...`, components: [] });
                
                const success = await enviarMensagemRobux(interaction, channelId, client);
                if (success) {
                    await interaction.editReply({ content: `${Emojis.get('checker')} | Mensagem enviada com sucesso no canal <#${channelId}>!` });
                } else {
                    await interaction.editReply({ content: `${Emojis.get('negative')} | Erro ao enviar a mensagem!` });
                }
            }

            
            if (interaction.customId.startsWith('ticket_channel_postar_')) {
                const painelId = interaction.customId.replace('ticket_channel_postar_', '');
                const channelId = interaction.values[0];
                await interaction.update({ content: `${Emojis.get('loading')} | Postando ticket...`, components: [] });
                const channel = await client.channels.fetch(channelId);
                await PostarTicket(interaction, painelId, channel);
            }

        }

        
        if (interaction.isChannelSelectMenu()) {
            if (interaction.customId.startsWith('sorteio_select_canal_')) {
                const sorteioId = interaction.customId.replace('sorteio_select_canal_', '');
                const canalId = interaction.values[0];
                
                sorteios.set(`${sorteioId}.canalId`, canalId);

                await PaginaGerenciarCargos(interaction, sorteioId);
            }

            
            if (interaction.customId === 'stock_select_canal_logs') {
                const canalId = interaction.values[0];
                configuracao.set('solicitarStock.canalLogs', canalId);
                
                const { PainelSolicitarStock } = require("../../Functions/PainelSolicitarStock.js");
                await PainelSolicitarStock(interaction, client);
            }

            
            if (interaction.customId === 'stock_select_canal_postar') {
                const canalId = interaction.values[0];
                const { PostarPainelStock } = require("../../Functions/PainelSolicitarStock.js");
                await PostarPainelStock(interaction, canalId, client);
            }

            
            if (interaction.customId === 'sugestao_select_canal') {
                const canalId = interaction.values[0];
                configuracao.set('sistemaSugestoes.canal', canalId);
                const { PainelSistemaSugestoes } = require("../../Functions/SistemaSugestoes.js");
                await PainelSistemaSugestoes(interaction, client);
            }
        }

        
        if (interaction.isRoleSelectMenu()) {
            if (interaction.customId.startsWith('sorteio_cargos_permitidos_')) {
                const sorteioId = interaction.customId.replace('sorteio_cargos_permitidos_', '');
                const cargos = interaction.values;
                
                sorteios.set(`${sorteioId}.cargosPermitidos`, cargos);

                await interaction.reply({ content: `${Emojis.get('checker')} | Cargos permitidos atualizados!`, ephemeral: true });
            }

            if (interaction.customId.startsWith('sorteio_cargos_bloqueados_')) {
                const sorteioId = interaction.customId.replace('sorteio_cargos_bloqueados_', '');
                const cargos = interaction.values;
                
                sorteios.set(`${sorteioId}.cargosBloqueados`, cargos);

                await interaction.reply({ content: `${Emojis.get('checker')} | Cargos bloqueados atualizados!`, ephemeral: true });
            }

            
            if (interaction.customId === 'sugestao_select_cargo') {
                const cargoId = interaction.values[0];
                configuracao.set('sistemaSugestoes.cargoAvaliador', cargoId);
                const { PainelSistemaSugestoes } = require("../../Functions/SistemaSugestoes.js");
                await PainelSistemaSugestoes(interaction, client);
            }
        }

        if (interaction.isButton()) {

            
            if (interaction.customId.startsWith('produtos_page_')) {
                const page = parseInt(interaction.customId.split('_')[2], 10);
                await mostrarPaginaProdutos(interaction, page);
                return;
            }

            if (interaction.customId == 'sincronizarticket') {
                await interaction.reply({ content: `${Emojis.get('loading')} | Aguarde estamos atualizando suas mensagem!`, ephemeral: true });
                await Checkarmensagensticket(client)
                interaction.editReply({ content: `${Emojis.get('checker')} | Mensagens atualizada com sucesso!`, ephemeral: true });
            }


            if (interaction.customId == 'arquivar') {

                if (!interaction.member.roles.cache.has(configuracao.get('ConfigRoles.cargoadm')) && !interaction.member.roles.cache.has(configuracao.get('ConfigRoles.cargosup'))) return interaction.reply({ content: `${Emojis.get('negative')} | Você não tem permissão para fazer isso!`, ephemeral: true });

                try {
                    await interaction.channel.setArchived(true)
                } catch (error) { }
            }

            
            if (interaction.customId === 'painel_staff') {
                if (!interaction.member.roles.cache.has(configuracao.get('ConfigRoles.cargoadm')) && !interaction.member.roles.cache.has(configuracao.get('ConfigRoles.cargosup'))) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | Você não tem permissão para acessar o painel staff!`, ephemeral: true });
                }

                const selectMenu = new Discord.StringSelectMenuBuilder()
                    .setCustomId('staff_acoes_ticket')
                    .setPlaceholder('Selecione uma ação...')
                    .addOptions([
                        { label: 'Assumir Ticket', description: 'Assumir o atendimento deste ticket', value: 'assumir_ticket', emoji: { id: '1178067873894236311' } },
                        { label: 'Renomear Ticket', description: 'Alterar o nome do tópico', value: 'renomear_ticket', emoji: { id: '1178066208835252266' } },
                        { label: 'Adicionar Usuário', description: 'Adicionar alguém ao ticket', value: 'adicionar_usuario', emoji: { id: '1178067873894236311' } },
                        { label: 'Remover Usuário', description: 'Remover alguém do ticket', value: 'remover_usuario', emoji: { id: '1178076767567757312' } }
                    ]);

                const row = new ActionRowBuilder().addComponents(selectMenu);

                await interaction.reply({ content: `${Emojis.get('ticketpanel')} **Painel da Equipe Staff**\n> Selecione uma ação abaixo:`, components: [row], ephemeral: true });
            }

              if (interaction.customId === 'deletar') {
                if (!interaction.member.roles.cache.has(configuracao.get('ConfigRoles.cargoadm')) &&
                    !interaction.member.roles.cache.has(configuracao.get('ConfigRoles.cargosup'))) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | Você não tem permissão para fazer isso!`, ephemeral: true });
                }
            
                try {
                    const ticketId = interaction.channel.id;
                    const { Temporario, transcript } = require("../../DataBaseJson");
                    
                    
                    let threadOwnerId = Temporario.get(`ticket_owner_${ticketId}`);
                    let categoria = Temporario.get(`ticket_categoria_${ticketId}`);
                    
                    if (!threadOwnerId) {
                        const threadNameParts = interaction.channel.name.split('・');
                        categoria = threadNameParts[0] || 'Ticket';
                        threadOwnerId = threadNameParts[2];
                    }
                    
                    if (!categoria) {
                        const threadNameParts = interaction.channel.name.split('・');
                        categoria = threadNameParts[0] || 'Ticket';
                    }
            
                    
                    const fetchedMessages = await interaction.channel.messages.fetch({ limit: 100 });
                    const messagesArray = Array.from(fetchedMessages.values()).reverse().map(msg => ({
                        author: msg.author.tag,
                        authorId: msg.author.id,
                        content: msg.content || '[Sem conteúdo]',
                        timestamp: msg.createdAt.toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' })
                    }));
                    
                    
                    const userMessages = messagesArray.filter(m => !m.content.startsWith('[Sem conteúdo]') && m.content.trim() !== '');
                    
                    
                    if (userMessages.length > 0) {
                        
                        const transcriptId = `${Date.now()}_${threadOwnerId}`;
                        const transcriptData = {
                            categoria,
                            ownerId: threadOwnerId,
                            fechadoPor: interaction.user.tag,
                            fechadoPorId: interaction.user.id,
                            fechadoEm: new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' }),
                            mensagens: messagesArray,
                            guildName: interaction.guild.name,
                            guildId: interaction.guild.id
                        };
                        
                        transcript.set(transcriptId, transcriptData);

                        
                        try {
                            const owner = await interaction.client.users.fetch(threadOwnerId);
                            
                            const containerFechado = res.main(
                                { type: 10, content: `# ${Emojis.get('_trash_emoji')} Ticket Fechado` },
                                { type: 14 },
                                { type: 10, content: `> Seu ticket de **${categoria}** foi encerrado.` },
                                { type: 14 },
                                { type: 10, content: `**Fechado por**\n${interaction.user.tag}` },
                                { type: 10, content: `**Data**\n<t:${Math.floor(Date.now() / 1000)}:f>` },
                                { type: 14 },
                                { type: 10, content: `-# Clique no botão abaixo para receber o transcript do atendimento.` },
                                { type: 1, components: [{ type: 2, style: 2, label: 'Gerar Transcript', custom_id: `gerar_transcript_${transcriptId}`, emoji: { id: '1384035207598051431' } }] }
                            );

                            await owner.send(containerFechado);
                        } catch (dmError) {
                            console.error('Não foi possível enviar DM para o usuário:', dmError);
                        }
                    } else {
                        
                        try {
                            const owner = await interaction.client.users.fetch(threadOwnerId);
                            
                            const containerFechado = res.main(
                                { type: 10, content: `# ${Emojis.get('_trash_emoji')} Ticket Fechado` },
                                { type: 14 },
                                { type: 10, content: `> Seu ticket de **${categoria}** foi encerrado.` },
                                { type: 14 },
                                { type: 10, content: `**Fechado por**\n${interaction.user.tag}` },
                                { type: 10, content: `**Data**\n<t:${Math.floor(Date.now() / 1000)}:f>` }
                            );

                            await owner.send(containerFechado);
                        } catch (dmError) {
                            console.error('Não foi possível enviar DM para o usuário:', dmError);
                        }
                    }

                    
                    const fs = require('fs');
                    const messagesContent = messagesArray.map(m => `[${m.timestamp}] ${m.author}: ${m.content}`).join('\n');
                    fs.writeFileSync('mensagens_antigas.txt', messagesContent);
            
                    
                    await interaction.channel.delete();
            
                    
                    const embed = new EmbedBuilder()
                        .setColor('#ff0000')
                        .setTitle(`Ticket Fechado: ${categoria}`)
                        .setDescription(`O ticket foi fechado por ${interaction.user} \`(${interaction.user.id})\`\n**Usuário:** <@${threadOwnerId}>`)
                        .setTimestamp();
            
                    
                    const logsChannelId = configuracao.get(`ConfigChannels.logsticket`);
                    const logsChannel = interaction.guild.channels.cache.get(logsChannelId);
                    if (logsChannel) {
                        await logsChannel.send({ embeds: [embed], files: [{ attachment: 'mensagens_antigas.txt', name: 'transcript.txt' }] });
                    }
                } catch (error) {
                    console.error('Erro ao deletar o canal:', error);
                }
            }

            if (interaction.customId === 'lembrar123') {
                if (!interaction.member.roles.cache.has(configuracao.get('ConfigRoles.cargoadm')) && !interaction.member.roles.cache.has(configuracao.get('ConfigRoles.cargosup'))) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | Você não tem permissão para fazer isso!`, ephemeral: true });
                }
            
                try {
                    const ticketId = interaction.channel.id;
                    const { Temporario } = require("../../DataBaseJson");
                    
                    
                    let threadOwnerId = Temporario.get(`ticket_owner_${ticketId}`);
                    if (!threadOwnerId) {
                        const threadNameParts = interaction.channel.name.split('・');
                        threadOwnerId = threadNameParts[2];
                    }
                    
                    if (!threadOwnerId || !/^\d+$/.test(threadOwnerId)) {
                        return interaction.reply({ content: `${Emojis.get('negative')} | Não foi possível identificar o dono do ticket.`, ephemeral: true });
                    }
                    
                    const user = await interaction.client.users.fetch(threadOwnerId);
            
                    
                    const brazilTime = new Date().toLocaleString("en-US", {timeZone: "America/Sao_Paulo"});
                    const hour = new Date(brazilTime).getHours();
                    let saudacao;
            
                    if (hour >= 0 && hour < 12) {
                        saudacao = 'Bom dia';
                    } else if (hour >= 12 && hour < 18) {
                        saudacao = 'Boa tarde';
                    } else {
                        saudacao = 'Boa noite';
                    }
            
                    
                    const mensagem = `${saudacao} <@${threadOwnerId}>, você possui um ticket pendente de resposta; se não for respondido, poderá ser fechado.`;
            
                    const row = new ActionRowBuilder() .addComponents(
                        new ButtonBuilder()
                            .setURL(`https://discord.com/channels/${interaction.guild.id}/${interaction.channel.id}`)
                            .setLabel('Ir para o Ticket')
                            .setStyle('5')
                    );
        
                    await user.send({
                        content: mensagem,
                        components: [row]
                    });
            
                    await interaction.reply({ content: `${Emojis.get('checker')} | Mensagem enviada ao criador do ticket.`, ephemeral: true });
            
                } catch (error) {
                    await interaction.reply({ content: `${Emojis.get('negative')} | Não foi possível enviar a mensagem, pois o usuário provavelmente bloqueou mensagens privadas.`, ephemeral: true });
                }
            }            

            if (interaction.customId == `postarticket`) {
                const ggg = tickets.get(`tickets.funcoes`)
                const ggg2 = tickets.get(`tickets.aparencia`)


                if (ggg == null || Object.keys(ggg).length == 0 || ggg2 == null || Object.keys(ggg2).length == 0) {
                    return interaction.reply({ content: `${Emojis.get('negative')} Adicione uma função antes de postar a mensagem.`, ephemeral: true });
                } else {
                    const selectaaa = new Discord.ChannelSelectMenuBuilder()
                        .setCustomId('canalpostarticket')
                        .setPlaceholder('Clique aqui para selecionar')
                        .setChannelTypes(Discord.ChannelType.GuildText)

                    const row1 = new ActionRowBuilder()
                        .addComponents(selectaaa);

                    interaction.reply({ components: [row1], content: `${Emojis.get('info')} Selecione o canal onde quer postar a mensagem.`, ephemeral: true, })

                }
            }



            if (interaction.customId == 'remfuncaoticket') {
                const ggg = tickets.get(`tickets.funcoes`)
                    
                if (ggg == null || Object.keys(ggg).length == 0) {
                    return interaction.reply({ content: `${Emojis.get('negative')} Não existe nenhuma função criada para remover.`, ephemeral: true });
                } else {
                    const selectMenuBuilder = new Discord.StringSelectMenuBuilder()
                        .setCustomId('deletarticketsfunction')
                        .setPlaceholder('Clique aqui para selecionar')
                        .setMinValues(0)

                    for (const chave in ggg) {
                        const item = ggg[chave];
                        const option = {
                            label: `${item.nome}`,
                            description: `${item.predescricao}`,
                            value: item.nome
                        };
                        selectMenuBuilder.addOptions(option);
                    }

                    selectMenuBuilder.setMaxValues(Object.keys(ggg).length)

                    const style2row = new ActionRowBuilder().addComponents(selectMenuBuilder);
                    try {
                        await interaction.reply({ components: [style2row], content: `${interaction.user} Qual funções deseja remover?`, ephemeral: true })
                    } catch (error) {
                    }
                }
            }


            if (interaction.customId == 'rendimento') {
                const row = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId("todayyyy")
                            .setLabel('Hoje')
                            .setStyle(2)
                            .setDisabled(false),
                        new ButtonBuilder()
                            .setCustomId("7daysss")
                            .setLabel('Últimos 7 dias')
                            .setStyle(2)
                            .setDisabled(false),
                        new ButtonBuilder()
                            .setCustomId("30dayss")
                            .setLabel('Últimos 30 dias')
                            .setStyle(2)
                            .setDisabled(false),
                        new ButtonBuilder()
                            .setCustomId("totalrendimento")
                            .setLabel('Rendimento Total')
                            .setStyle(3)
                            .setDisabled(false),
                    )
                interaction.reply({ content: `Olá senhor **${interaction.user.username}**, selecione algum filtro.`, components: [row], ephemeral: true })
            }

            if (interaction.customId == 'gerenciarposicao') {

                Posicao1(interaction, client)

            }



            if (interaction.customId == 'Editarprimeiraposição') {

                const aa = configuracao.get(`posicoes`)

                const modalaAA = new ModalBuilder()
                    .setCustomId('aslfdjauydvaw769dg7waajnwndjo')
                    .setTitle(`Definir primeira posição`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`VALOR`)
                    .setPlaceholder(`Insira uma quantia, ex: 100`)
                    .setValue(aa?.pos1?.valor == undefined ? '' : aa.pos1?.valor)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`CARGO`)
                    .setPlaceholder(`Insira um id de algum cargo`)
                    .setValue(aa?.pos1?.role == undefined ? '' : aa.pos1?.role)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);

                modalaAA.addComponents(firstActionRow3, firstActionRow4);

                await interaction.showModal(modalaAA);
            }

            if (interaction.customId == 'Editarsegundaposição') {
                const aa = configuracao.get(`posicoes`)

                const modalaAA = new ModalBuilder()
                    .setCustomId('awiohdbawudwdwhduawdnuaw')
                    .setTitle(`Definir segunda posição`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`VALOR`)
                    .setPlaceholder(`Insira uma quantia, ex: 100`)
                    .setValue(aa?.pos2?.valor == undefined ? '' : aa.pos2?.valor)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`CARGO`)
                    .setPlaceholder(`Insira um id de algum cargo`)
                    .setValue(aa?.pos2?.role == undefined ? '' : aa.pos2?.role)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);

                modalaAA.addComponents(firstActionRow3, firstActionRow4);

                await interaction.showModal(modalaAA);
            }

            if (interaction.customId == 'Editarterceiraposição') {
                const aa = configuracao.get(`posicoes`)
                const modalaAA = new ModalBuilder()
                    .setCustomId('uy82819171h172')
                    .setTitle(`Definir terceira posição`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`VALOR`)
                    .setPlaceholder(`Insira uma quantia, ex: 100`)
                    .setValue(aa?.pos3?.valor == undefined ? '' : aa.pos3?.valor)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`CARGO`)
                    .setPlaceholder(`Insira um id de algum cargo`)
                    .setValue(aa?.pos3?.role == undefined ? '' : aa.pos3?.role)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);

                modalaAA.addComponents(firstActionRow3, firstActionRow4);

                await interaction.showModal(modalaAA);
            }


            if (interaction.customId == 'todayyyy' || interaction.customId == '7daysss' || interaction.customId == '30dayss' || interaction.customId == 'totalrendimento') {

                let rendimento
                let name

                if (interaction.customId == 'todayyyy') {
                    rendimento = await EstatisticasNxy.SalesToday()
                    name = 'Resumo das vendas de hoje'
                } else if (interaction.customId == '7daysss') {
                    rendimento = await EstatisticasNxy.SalesWeek()
                    name = 'Resumo das vendas nos últimos 7 dias'
                } else if (interaction.customId == '30dayss') {
                    rendimento = await EstatisticasNxy.SalesMonth()
                    name = 'Resumo das vendas nos últimos 30 dias'
                } else if (interaction.customId == 'totalrendimento') {
                    name = 'Resumo geral de todas as vendas'
                    rendimento = await EstatisticasNxy.SalesTotal()
                }


                const embed = new EmbedBuilder()
                    .setColor(`${configuracao.get(`Cores.Principal`) == null ? '0cd4cc': configuracao.get('Cores.Principal')}`)
                    .setTitle(`${name}`)
                    .addFields(
                        { name: `**Rendimento**`, value: `\`R$ ${Number(rendimento.rendimentoTotal).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\``, inline: true },
                        { name: `**Pedidos aprovados**`, value: `\`${rendimento.quantidadeTotal}\``, inline: true },
                        { name: `**Produtos entregues**`, value: `\`${rendimento.produtosEntregue}\``, inline: true },
                    )
                    .setAuthor({ name: `${interaction.user.username}` })
                    .setTimestamp()
                    .setFooter({ text: `${interaction.user.username}` })

                interaction.update({ embeds: [embed] })
            }



            if (interaction.customId.startsWith('criarrrr')) {

                const modalaAA = new ModalBuilder()
                    .setCustomId('sdaju11111idsjjsdua')
                    .setTitle(`Criação`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`NOME`)
                    .setPlaceholder(`Insira o nome do seu produto`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`DESCRIÇÃO`)
                    .setPlaceholder(`Insira uma descrição para seu produto`)
                    .setStyle(TextInputStyle.Paragraph)
                    .setRequired(true)
                    .setMaxLength(1024)

                const newnameboteN4 = new TextInputBuilder()
                    .setCustomId('tokenMP3')
                    .setLabel(`ENTREGA AUTOMÁTICA?`)
                    .setPlaceholder(`Digite "sim" ou "não"`)
                    .setStyle(TextInputStyle.Short)
                    .setMaxLength(3)
                    .setRequired(true)

                const newnameboteN5 = new TextInputBuilder()
                    .setCustomId('tokenMP4')
                    .setLabel(`ICONE (OPCIONAL)`)
                    .setPlaceholder(`Insira uma URL de uma imagem ou gif`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN6 = new TextInputBuilder()
                    .setCustomId('tokenMP5')
                    .setLabel(`BANNER (OPCIONAL)`)
                    .setPlaceholder(`Insira uma URL de uma imagem ou gif`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);
                const firstActionRow5 = new ActionRowBuilder().addComponents(newnameboteN4);
                const firstActionRow6 = new ActionRowBuilder().addComponents(newnameboteN5);
                const firstActionRow7 = new ActionRowBuilder().addComponents(newnameboteN6);



                modalaAA.addComponents(firstActionRow3, firstActionRow4, firstActionRow5, firstActionRow6, firstActionRow7);
                await interaction.showModal(modalaAA);

            }

            if (interaction.customId.startsWith('infoauth')) {

                infoauth(interaction, client)

            }

            if (interaction.customId.startsWith('voltarconfigauth')) {

                configauth(interaction, client)

            }
             if (interaction.customId.startsWith('sistemaauth')) {

                auth02api(interaction, client)

            }

            if (interaction.customId.startsWith('infosauth')) {

                infosauth(interaction, client)

            } 
              if (interaction.customId.startsWith('configurarmistic')) {

                misticConfigs(interaction, client)

            }

            if (interaction.customId.startsWith('config_pagamentos_inter')) {

                imapConfigs(interaction, client)

            }
          
             if (interaction.customId == "altMoeda") {

                await interaction.update({ content: `${Emojis.get(`loading`)} Carregando...`, embeds: [], components: [] });

                moedaConfig(interaction, client);

            }
          
            if (interaction.customId.startsWith('voltarauth')) {

                ecloud(interaction, client)

            }

            if (interaction.customId.startsWith('voltar1')) {
                try {
                await Painel(interaction, client);
                  } catch (err) {
                 console.error('Erro ao executar Painel:', err);
                await interaction.reply({ content: '❌ Ocorreu um erro.', ephemeral: true });
                }
              }



            if (interaction.customId.startsWith('addfuncaoticket')) {

                const dd = tickets.get('tickets.funcoes')
               
                
                if (dd && Object.keys(dd).length > 24) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | Você não pode criar mais de 24 funções em seu TICKET!` });
                }
                  
                const modalaAA = new ModalBuilder()
                    .setCustomId('sdaju11111231idsj1233js123dua123')
                    .setTitle(`Adicionar função`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`NOME DA FUNÇÃO`)
                    .setPlaceholder(`Insira aqui um nome, como: Suporte`)
                    .setStyle(TextInputStyle.Short)

                    .setRequired(true)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`PRÉ DESCRIÇÃO`)
                    .setPlaceholder(`Insira aqui uma pré descrição, ex: "Preciso de suporte."`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true)
                    .setMaxLength(99)

                const newnameboteN4 = new TextInputBuilder()
                    .setCustomId('tokenMP3')
                    .setLabel(`DESCRIÇÃO`)
                    .setPlaceholder(`Insira aqui a descrição da função.`)
                    .setStyle(TextInputStyle.Paragraph)
                    .setRequired(false)
                    .setMaxLength(99)

                const newnameboteN5 = new TextInputBuilder()
                    .setCustomId('tokenMP5')
                    .setLabel(`BANNER (OPCIONAL)`)
                    .setPlaceholder(`Insira aqui uma URL de uma imagem ou GIF`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN6 = new TextInputBuilder()
                    .setCustomId('tokenMP6')
                    .setLabel(`EMOJI DA FUNÇÃO`)
                    .setPlaceholder(`Insira um nome ou id de um emoji do servidor.`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);
                const firstActionRow5 = new ActionRowBuilder().addComponents(newnameboteN4);
                const firstActionRow6 = new ActionRowBuilder().addComponents(newnameboteN5);
                const firstActionRow7 = new ActionRowBuilder().addComponents(newnameboteN6);


                modalaAA.addComponents(firstActionRow3, firstActionRow4, firstActionRow5, firstActionRow6, firstActionRow7);
                await interaction.showModal(modalaAA);

            }
            if (interaction.customId.startsWith('definiraparencia')) {



                const modalaAA = new ModalBuilder()
                    .setCustomId('0-89du0awd8awdaw8daw')
                    .setTitle(`Editar Ticket`);

                const dd = tickets.get(`tickets.aparencia`)

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`TITULO`)
                    .setPlaceholder(`Insira aqui um nome, como: Entrar em contato`)
                    .setStyle(TextInputStyle.Short)
                    .setValue(dd?.title == undefined ? '' : dd.title)
                    .setRequired(true)


                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`DESCRIÇÃO`)
                    .setPlaceholder(`Insira aqui uma descrição.`)
                    .setStyle(TextInputStyle.Paragraph)
                    .setValue(dd?.description == undefined ? '' : dd.description)
                    .setMaxLength(500)
                    .setRequired(true)


                const newnameboteN4 = new TextInputBuilder()
                    .setCustomId('tokenMP3')
                    .setLabel(`BANNER (OPCIONAL)`)
                    .setPlaceholder(`Insira aqui uma URL de uma imagem ou GIF`)
                    .setStyle(TextInputStyle.Short)
                    .setValue(dd?.banner == undefined ? '' : dd.banner)
                    .setRequired(false)



                const newnameboteN5 = new TextInputBuilder()
                    .setCustomId('tokenMP5')
                    .setLabel(`COR DO EMBED (OPCIONAL)`)
                    .setPlaceholder(`Insira aqui um código Hex Color, ex: FFFFFF`)
                    .setStyle(TextInputStyle.Short)
                    .setValue(dd?.color == undefined ? '' : dd.color)
                    .setRequired(false)


                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);
                const firstActionRow5 = new ActionRowBuilder().addComponents(newnameboteN4);
                const firstActionRow6 = new ActionRowBuilder().addComponents(newnameboteN5);

                modalaAA.addComponents(firstActionRow3, firstActionRow4, firstActionRow5, firstActionRow6);
                await interaction.showModal(modalaAA);



            }

            if (interaction.customId.startsWith('painelconfigticket')) {
                painelTicket(interaction)
            }

            
            if (interaction.customId === 'ticket_criar_painel') {
                await ModalCriarPainelTicket(interaction);
            }

            
            if (interaction.customId === 'ticket_voltar_lista') {
                await painelTicket(interaction);
            }

            
            if (interaction.customId.startsWith('ticket_editar_')) {
                const painelId = interaction.customId.replace('ticket_editar_', '');
                await ModalEditarPainel(interaction, painelId);
            }

            
            if (interaction.customId.startsWith('ticket_addfuncao_')) {
                const painelId = interaction.customId.replace('ticket_addfuncao_', '');
                await ModalAddFuncaoTicket(interaction, painelId);
            }

            
            if (interaction.customId.startsWith('ticket_remfuncao_')) {
                const painelId = interaction.customId.replace('ticket_remfuncao_', '');
                await PaginaRemoverFuncao(interaction, painelId);
            }

            
            if (interaction.customId.startsWith('ticket_gerenciar_')) {
                const painelId = interaction.customId.replace('ticket_gerenciar_', '');
                await PaginaGerenciarPainel(interaction, painelId);
            }

            
            if (interaction.customId.startsWith('ticket_preview_')) {
                const painelId = interaction.customId.replace('ticket_preview_', '');
                await PreviewTicket(interaction, painelId);
            }

            
            if (interaction.customId.startsWith('ticket_categorias_')) {
                const painelId = interaction.customId.replace('ticket_categorias_', '');
                await PaginaCategorias(interaction, painelId);
            }

            
            if (interaction.customId.startsWith('painelconfigrobux')) {
                painelRobux(interaction)
            }

            
            if (interaction.customId === 'robux_config_canais') {
                await configCanaisRobux(interaction);
            }

            
            if (interaction.customId === 'robux_config_valores') {
                await modalConfigValores(interaction);
            }

            
            if (interaction.customId === 'robux_config_limites') {
                await modalConfigLimites(interaction);
            }

            
            if (interaction.customId === 'voltar_robux_painel') {
                await painelRobux(interaction);
            }

            
            if (interaction.customId === 'robux_config_mensagem') {
                await painelConfigMensagem(interaction);
            }

            
            if (interaction.customId === 'robux_enviar_mensagem') {
                const Discord = require("discord.js");
                const selectChannel = new Discord.ChannelSelectMenuBuilder()
                    .setCustomId(`robux_channel_enviar_mensagem`)
                    .setPlaceholder('Selecione o canal para enviar a mensagem')
                    .setChannelTypes(Discord.ChannelType.GuildText);

                const row = new ActionRowBuilder().addComponents(selectChannel);
                await interaction.reply({ 
                    content: `${Emojis.get('info')} | Selecione o canal onde deseja enviar a mensagem de compra:`, 
                    components: [row], 
                    ephemeral: true 
                });
            }

            
            if (interaction.customId === 'robux_configurar_container') {
                await modalConfigurarContainer(interaction);
            }

            
            if (interaction.customId === 'robux_visualizar_mensagem') {
                await visualizarMensagem(interaction);
            }

            
            if (interaction.customId === 'voltar_config_mensagem') {
                await painelConfigMensagem(interaction);
            }

            if (interaction.customId === 'robux_personalizar') {
                await interaction.reply({ content: `${Emojis.get('negative')} | Esta função ainda está em desenvolvimento.`, ephemeral: true });
            }

            
            if (interaction.customId === 'robux_iniciar_compra_robux') {
                await modalNickRoblox(interaction, 'robux');
            }

            
            if (interaction.customId === 'robux_iniciar_compra_gamepass') {
                await modalNickRoblox(interaction, 'gamepass');
            }

            
            if (interaction.customId === 'robux_cancelar_compra') {
                await cancelarCompra(interaction, client);
            }

            
            if (interaction.customId === 'robux_atualizar_gamepass') {
                await atualizarGamepasses(interaction);
            }

            
            if (interaction.customId === 'robux_voltar_gamepasses') {
                await voltarParaGamepasses(interaction);
            }

            
            if (interaction.customId === 'robux_ir_pagamento') {
                await irParaPagamentoRobux(interaction, client);
            }

            
            if (interaction.customId === 'robux_copiar_pix') {
                await copiarPixRobux(interaction);
            }

            
            if (interaction.customId === 'robux_copiar_pix_semi') {
                const { carrinhosRobux } = require("../../Functions/CarrinhoRobux");
                const carrinho = carrinhosRobux.get(`${interaction.user.id}`);
                
                if (carrinho && carrinho.pagamento?.pixCopiaCola) {
                    const pagamento = configuracao.get(`pagamentos.SemiAutomatico`);
                    await interaction.reply({ 
                        content: `Chave pix: ${pagamento?.pix || carrinho.pagamento.pixCopiaCola}`, 
                        ephemeral: true 
                    });
                } else {
                    await interaction.reply({ 
                        content: `${Emojis.get('negative') || '❌'} | Código PIX não encontrado!`, 
                        ephemeral: true 
                    });
                }
            }

            
            if (interaction.customId === 'robux_confirmar_pagamento_manual') {
                const { confirmarPagamentoManualRobux } = require("../../Functions/PagamentoRobux");
                await confirmarPagamentoManualRobux(interaction, client);
            }

            
            if (interaction.customId.startsWith('robux_entrega_concluida_')) {
                const pedidoId = interaction.customId.replace('robux_entrega_concluida_', '');
                await confirmarEntregaRobux(interaction, pedidoId, client);
            }



            if (interaction.customId.startsWith('personalizarbot')) {

                const modalaAA = new ModalBuilder()
                    .setCustomId('sdaju11111231idsjjs123dua123')
                    .setTitle(`Editar perfil do bot`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`NOME DE USUÁRIO`)
                    .setValue(`${client.user.username}`)
                    .setPlaceholder(`Insira um nome de usuário (só pode mudar 3x por hora)`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`AVATAR`)
                    .setPlaceholder(`Insira uma URL de um ícone`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN4 = new TextInputBuilder()
                    .setCustomId('tokenMP3')
                    .setLabel(`STATUS 1`)
                    .setPlaceholder(`Insira aqui um status personalizado`)
                    
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN5 = new TextInputBuilder()
                    .setCustomId('tokenMP5')
                    .setLabel(`STATUS 2`)
                    
                    .setPlaceholder(`Insira aqui um status personalizado`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);
                const firstActionRow5 = new ActionRowBuilder().addComponents(newnameboteN4);
                const firstActionRow6 = new ActionRowBuilder().addComponents(newnameboteN5);

                modalaAA.addComponents(firstActionRow3, firstActionRow4, firstActionRow5, firstActionRow6);
                await interaction.showModal(modalaAA);

            }


            if (interaction.customId.startsWith('coresembeds')) {

                const modalaAA = new ModalBuilder()
                    .setCustomId('sdaju11111idsjjs123dua123')
                    .setTitle(`Editar cores dos embeds`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`COR PRINCIPAL`)
                    .setPlaceholder(`Insira aqui um código Hex Color, ex: #Obd4cd`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`COR DE PROCESSAMENTO`)
                    .setPlaceholder(`Insira aqui um código Hex Color, ex: #fcba03`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN4 = new TextInputBuilder()
                    .setCustomId('tokenMP3')
                    .setLabel(`COR DE SUCESSO`)
                    .setPlaceholder(`Insira aqui um código Hex Color, ex: #39fc03`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN5 = new TextInputBuilder()
                    .setCustomId('tokenMP5')
                    .setLabel(`COR DE FALHA`)
                    .setPlaceholder(`Insira aqui um código Hex Color, ex: #ff0000`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN6 = new TextInputBuilder()
                    .setCustomId('tokenMP6')
                    .setLabel(`COR DE FINALIZADO`)
                    .setPlaceholder(`Insira aqui um código Hex Color, ex: #7363ff`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);
                const firstActionRow5 = new ActionRowBuilder().addComponents(newnameboteN4);
                const firstActionRow6 = new ActionRowBuilder().addComponents(newnameboteN5);
                const firstActionRow7 = new ActionRowBuilder().addComponents(newnameboteN6);



                modalaAA.addComponents(firstActionRow3, firstActionRow4, firstActionRow5, firstActionRow6, firstActionRow7);
                await interaction.showModal(modalaAA);

            }



            if (interaction.customId.startsWith('voltar2')) {
                Gerenciar(interaction, client)

            }

            if (interaction.customId.startsWith('eaffaawwawa')) {
                automatico(interaction, client)
            }

            if (interaction.customId === 'nxyai_dev') {
                interaction.reply({ 
                    content: `🤖 **NOXY AI** está em desenvolvimento!\n\n> Em breve você terá acesso a recursos de inteligência artificial para automatizar ainda mais seu servidor.`, 
                    ephemeral: true 
                });
            }
            if (interaction.customId.startsWith('voltarautomaticos')) {
                automatico(interaction, client)
            }

            
            if (interaction.customId === 'sugestao_config_canal') {
                const { PaginaConfigurarCanal } = require("../../Functions/SistemaSugestoes.js");
                PaginaConfigurarCanal(interaction);
            }

            if (interaction.customId === 'sugestao_config_cargo') {
                const { PaginaConfigurarCargo } = require("../../Functions/SistemaSugestoes.js");
                PaginaConfigurarCargo(interaction);
            }

            if (interaction.customId === 'sugestao_toggle') {
                const { ToggleSugestoes } = require("../../Functions/SistemaSugestoes.js");
                ToggleSugestoes(interaction, client);
            }

            if (interaction.customId === 'sugestao_voltar_painel') {
                const { PainelSistemaSugestoes } = require("../../Functions/SistemaSugestoes.js");
                PainelSistemaSugestoes(interaction, client);
            }

            
            if (interaction.customId.startsWith('sug_votar_pos_')) {
                const sugestaoId = interaction.customId.replace('sug_votar_pos_', '');
                const { VotarSugestao } = require("../../Functions/SistemaSugestoes.js");
                VotarSugestao(interaction, sugestaoId, 'positivo');
            }

            if (interaction.customId.startsWith('sug_votar_neg_')) {
                const sugestaoId = interaction.customId.replace('sug_votar_neg_', '');
                const { VotarSugestao } = require("../../Functions/SistemaSugestoes.js");
                VotarSugestao(interaction, sugestaoId, 'negativo');
            }

            if (interaction.customId.startsWith('sug_gerenciar_')) {
                const sugestaoId = interaction.customId.replace('sug_gerenciar_', '');
                const { GerenciarSugestao } = require("../../Functions/SistemaSugestoes.js");
                GerenciarSugestao(interaction, sugestaoId);
            }

            if (interaction.customId.startsWith('sug_aprovar_')) {
                const sugestaoId = interaction.customId.replace('sug_aprovar_', '');
                const { AprovarSugestao } = require("../../Functions/SistemaSugestoes.js");
                AprovarSugestao(interaction, sugestaoId);
            }

            if (interaction.customId.startsWith('sug_reprovar_')) {
                const sugestaoId = interaction.customId.replace('sug_reprovar_', '');
                const { ReprovarSugestao } = require("../../Functions/SistemaSugestoes.js");
                ReprovarSugestao(interaction, sugestaoId);
            }

            if (interaction.customId === 'sug_cancelar_gerenciar') {
                await interaction.update({ content: `${Emojis.get('checker')} | Ação cancelada.`, components: [] });
            }

            if (interaction.customId.startsWith('ecloud')) {
                ecloud(interaction, client)
            }

            if (interaction.customId.startsWith('configauth')) {
                configauth(interaction, client)
            }

            if (interaction.customId.startsWith('gerenciarconfigs')) {
                Gerenciar(interaction, client)
            }
            if (interaction.customId.startsWith('configcargos')) {
                ConfigRoles(interaction, client)
            
            }
            if (interaction.customId.startsWith('painelpersonalizar')) {


                const row2 = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId("coresembeds")
                            .setLabel('Editar cores dos embeds')
                            .setEmoji(`1178080366871973958`)
                            .setStyle(1),

                        new ButtonBuilder()
                            .setCustomId("personalizarbot")
                            .setLabel('Personalizar Bot')
                            .setEmoji(`1178080828933283960`)
                            .setStyle(1),

                        new ButtonBuilder()
                            .setCustomId("definirtema")
                            .setLabel('Definir tema')
                            .setEmoji(`1178066208835252266`)
                            .setDisabled(false)
                            .setStyle(1)
                    )

                const row3 = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId("voltar1")
                            .setLabel('Voltar')
                            .setEmoji(`1178068047202893869`)
                            .setStyle(2)
                    )

                interaction.reply({ embeds: [], components: [row2, row3], content: `Escolha uma opção e use sua criatividade e profissionalismo ;) `, ephemeral: true })


            }
            if (interaction.customId.startsWith('painelconfigbv')) {

                msgbemvindo(interaction, client)

            }
            if (interaction.customId.startsWith('gerenciarperm')) {
            GerenciarPermsADM(interaction, client);
            }
            if (interaction.customId.startsWith('systemsugestao')) {
            SistemaSugestao(interaction, client);
            }

            
            if (interaction.customId === 'stock_definir_canal') {
                const { PaginaDefinirCanalStock } = require("../../Functions/PainelSolicitarStock.js");
                PaginaDefinirCanalStock(interaction);
            }

            if (interaction.customId === 'stock_configurar_embed') {
                const { PaginaConfigurarEmbed } = require("../../Functions/PainelSolicitarStock.js");
                PaginaConfigurarEmbed(interaction, client);
            }

            if (interaction.customId === 'stock_enviar') {
                const { PaginaEscolherCanalPostar } = require("../../Functions/PainelSolicitarStock.js");
                PaginaEscolherCanalPostar(interaction);
            }

            if (interaction.customId === 'stock_resetar') {
                const { ResetarConfiguracoes } = require("../../Functions/PainelSolicitarStock.js");
                ResetarConfiguracoes(interaction, client);
            }

            if (interaction.customId === 'stock_visualizar') {
                const { VisualizarEmbed } = require("../../Functions/PainelSolicitarStock.js");
                VisualizarEmbed(interaction);
            }

            if (interaction.customId === 'stock_voltar_painel') {
                const { PainelSolicitarStock } = require("../../Functions/PainelSolicitarStock.js");
                PainelSolicitarStock(interaction, client);
            }

            if (interaction.customId === 'solicitar_estoque_btn') {
                const { ModalSolicitarEstoque } = require("../../Functions/PainelSolicitarStock.js");
                ModalSolicitarEstoque(interaction);
            }

            if (interaction.customId.startsWith('voltar3')) {

                Gerenciar2(interaction, client)

            }
            if (interaction.customId.startsWith('automaticRepostar')) {

                AcoesRepostAutomatics(interaction, client)

            }
            if (interaction.customId.startsWith('voltar00')) {

                Painel(interaction, client)

            }

            if (interaction.customId.startsWith('painelconfigvendas')) {


              Gerenciar2(interaction, client)
           }

            
            if (interaction.customId === 'painelextensoes') {
              PainelExtensoes(interaction, client);
           }

            
            if (interaction.customId === 'sistemamoderacao') {
              interaction.reply({ 
                content: `🛡️ **Sistema de Moderação** está em desenvolvimento!\n\n> Em breve você terá acesso a ferramentas de moderação avançadas para seu servidor.`, 
                ephemeral: true 
              });
           }

            
            if (interaction.customId === 'painelpermissions') {
              PainelPermissions(interaction, client);
           }

            
            if (interaction.customId === 'adicionar_perm') {
              ModalAdicionarPerm(interaction);
           }

            
            if (interaction.customId === 'remover_perm') {
              ModalRemoverPerm(interaction);
           }

            
            if (interaction.customId === 'resetar_perms') {
              HandleResetarPerms(interaction, client);
           }

            if (interaction.customId.startsWith('sistemasorteios')) {
              PainelSorteios(interaction, client);
           }

            
            if (interaction.customId === 'criar_sorteio') {
              ModalCriarSorteio(interaction);
           }

            
            if (interaction.customId === 'gerenciar_sorteios') {
              PaginaGerenciarSorteios(interaction, client);
           }

            
            if (interaction.customId.startsWith('gerenciar_sorteio_')) {
              const sorteioId = interaction.customId.replace('gerenciar_sorteio_', '');
              PaginaGerenciarSorteioEspecifico(interaction, sorteioId, client);
           }

            
            if (interaction.customId.startsWith('gerenciar_forcar_')) {
              const sorteioId = interaction.customId.replace('gerenciar_forcar_', '');
              PaginaConfirmarForcarFinalizacao(interaction, sorteioId);
           }

            
            if (interaction.customId.startsWith('confirmar_forcar_')) {
              const sorteioId = interaction.customId.replace('confirmar_forcar_', '');
              forcarFinalizacao(interaction, sorteioId, client);
           }

            
            if (interaction.customId.startsWith('gerenciar_addtempo_')) {
              const sorteioId = interaction.customId.replace('gerenciar_addtempo_', '');
              ModalAdicionarTempo(interaction, sorteioId);
           }

            
            if (interaction.customId.startsWith('gerenciar_descontinuar_')) {
              const sorteioId = interaction.customId.replace('gerenciar_descontinuar_', '');
              PaginaConfirmarDescontinuar(interaction, sorteioId);
           }

            
            if (interaction.customId.startsWith('confirmar_descontinuar_')) {
              const sorteioId = interaction.customId.replace('confirmar_descontinuar_', '');
              descontinuarSorteio(interaction, sorteioId, client);
           }

            
            if (interaction.customId.startsWith('gerenciar_verparticipantes_')) {
              const sorteioId = interaction.customId.replace('gerenciar_verparticipantes_', '');
              gerarListaParticipantes(interaction, sorteioId, client);
           }

            
            if (interaction.customId.startsWith('sorteio_tempo_manual_')) {
              const sorteioId = interaction.customId.replace('sorteio_tempo_manual_', '');
              ModalTempoPersonalizado(interaction, sorteioId);
           }

            
            if (interaction.customId.startsWith('sorteio_voltar_tempo_')) {
              const sorteioId = interaction.customId.replace('sorteio_voltar_tempo_', '');
              PaginaSetarTempo(interaction, sorteioId);
           }

            
            if (interaction.customId.startsWith('sorteio_voltar_canal_')) {
              const sorteioId = interaction.customId.replace('sorteio_voltar_canal_', '');
              PaginaEscolherCanal(interaction, sorteioId);
           }

            
            if (interaction.customId.startsWith('sorteio_finalizar_')) {
              const sorteioId = interaction.customId.replace('sorteio_finalizar_', '');
              EnviarMensagemSorteio(interaction, sorteioId, client);
           }

            
            if (interaction.customId.startsWith('sorteio_participar_')) {
              const sorteioId = interaction.customId.replace('sorteio_participar_', '');
              const sorteioData = sorteios.get(sorteioId);

              if (!sorteioData || sorteioData.status !== "ativo") {
                return interaction.reply({ content: `${Emojis.get('negative')} | Este sorteio não está mais ativo!`, ephemeral: true });
              }

              const userId = interaction.user.id;
              const participantes = sorteioData.participantes || [];

              
              if (sorteioData.cargosPermitidos && sorteioData.cargosPermitidos.length > 0) {
                const temCargoPermitido = sorteioData.cargosPermitidos.some(cargoId => 
                  interaction.member.roles.cache.has(cargoId)
                );
                if (!temCargoPermitido) {
                  return interaction.reply({ content: `${Emojis.get('negative')} | Você não possui os cargos necessários para participar!`, ephemeral: true });
                }
              }

              
              if (sorteioData.cargosBloqueados && sorteioData.cargosBloqueados.length > 0) {
                const temCargoBloqueado = sorteioData.cargosBloqueados.some(cargoId => 
                  interaction.member.roles.cache.has(cargoId)
                );
                if (temCargoBloqueado) {
                  return interaction.reply({ content: `${Emojis.get('negative')} | Você possui um cargo que não pode participar deste sorteio!`, ephemeral: true });
                }
              }

              if (participantes.includes(userId)) {
                return interaction.reply({ content: `${Emojis.get('negative')} | Você já está participando deste sorteio!`, ephemeral: true });
              }

              participantes.push(userId);
              sorteios.set(`${sorteioId}.participantes`, participantes);

              
              await atualizarEmbedSorteio(sorteioId, client);

              interaction.reply({ content: `${Emojis.get('checker')} | Você está participando do sorteio **${sorteioData.titulo}**! 🎉`, ephemeral: true });
           }

            
            if (interaction.customId.startsWith('sorteio_reroll_')) {
              const sorteioId = interaction.customId.replace('sorteio_reroll_', '');
              await rerollSorteio(interaction, sorteioId, client);
           }

            
            if (interaction.customId.startsWith('sorteio_lista_')) {
              const sorteioId = interaction.customId.replace('sorteio_lista_', '');
              await gerarListaParticipantes(interaction, sorteioId, client);
           }

            
            if (interaction.customId.startsWith('sorteio_cancelar_')) {
              const sorteioId = interaction.customId.replace('sorteio_cancelar_', '');
              sorteios.delete(sorteioId);
              PainelSorteios(interaction, client);
           }
        }
    }
}
