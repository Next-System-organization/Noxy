# NOXY — Histórico de Versões

## NXY OS v1.0.0 — Fundação
**Data:** 2026-08  
**Responsável:** Ayann — Next Studio

### O que é esta versão
Base técnica do NOXY, derivada de projeto anterior, completamente desvinculada
da identidade anterior e preparada para receber novas funcionalidades.

### Mudanças desta versão
- Identidade antiga completamente removida
- Nova identidade NOXY / Next Studio estabelecida
- Dados antigos limpos (perms, clientes, tickets, produtos, estatísticas)
- Credenciais antigas sinalizadas e substituídas por placeholders
- Telemetria para serviços de terceiros removida
- Arquitetura organizada para escalar
- NXY OS como nome interno do sistema operacional do bot
- EstatisticasNxy como classe de estatísticas interna

### Sistemas preservados e funcionais
- Sistema de Vendas (produtos, estoque, entrega)
- Sistema de Tickets
- Sistema de Pagamentos (MP, EFI, MisticPay, Inter, Pix Semi-Auto, IMAP)
- Sistema NXY Bux (Roblox GamePasses)
- Sistema de Sorteios
- Sistema de Sugestões
- Sistema de Logs e Auditoria
- Sistema de Boas Vindas
- Sistema de Autolock
- Sistema de Backup de Clientes
- Sistema de Mensagens Automáticas
- Sistema de Repostagem Automática
- Sistema de Permissões Avançadas
- Sistema de Configuração via Painel (Discord Components V2)
- Sistema de QR Code
- Sistema de Anti-Fake
- Sistema de Sincronização de Dados
- NXY Cloud (autenticação OAuth)
