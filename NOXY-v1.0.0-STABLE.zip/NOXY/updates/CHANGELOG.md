# NOXY — CHANGELOG

---

## [1.0.0] — 2026-08 — Fundação NOXY

### AUDITORIA REALIZADA
- 17 sistemas identificados e classificados
- ~21 comandos Slash (Administração + ContextMenus + Usuários)
- 32 ocorrências de identidade antiga removidas
- 3 credenciais críticas detectadas (tokens, OAuth secret, webhook)
- 1 sistema de telemetria de terceiros removido
- Dados de 11+ clientes antigos limpos
- Produtos e estatísticas de teste limpos

### IDENTIDADE
- [REMOVIDO] "Zyra Applications" → substituído por "NOXY / Next Studio"
- [REMOVIDO] "zOS" → substituído por "NXY OS"
- [REMOVIDO] "Zyra Cloud" → substituído por "NXY Cloud"
- [REMOVIDO] "Sistema Zyra Bux" → substituído por "NXY Bux"
- [REMOVIDO] "Ilusion Soluctions" → substituído por "Next Studio"
- [REMOVIDO] "Ilusion Cloud" → substituído por "NXY Cloud"
- [REMOVIDO] "Zyra AI" → substituído por "NOXY AI"
- [REMOVIDO] "ryzen-bot" (package.json) → substituído por "noxy"
- [REMOVIDO] "Noxen" (author) → substituído por "Ayann — Next Studio"
- [REMOVIDO] "Logs Bot Ryzen Systens" → substituído por "Logs NOXY"
- [REMOVIDO] "EstatisticasStorm" → padronizado para "EstatisticasNxy"

### SEGURANÇA
- [REMOVIDO] Token do bot de config.json → substituído por placeholder
- [REMOVIDO] OAuth secret de configauth.json → substituído por placeholder
- [REMOVIDO] URL de webhook de logs da configauth.json → substituído por placeholder
- [REMOVIDO] Segundo token do README.md (exposto em plain text)
- [REMOVIDO] Chamada POST automática para ilusionsoluctions.com.br no evento ready
  (FunctionReady.js enviava dados do servidor + invite para API de terceiro)
- [REMOVIDO] updateBio() automático que sobrescrevia a bio do bot com "Zyra Applications"
- [REMOVIDO] redirect para ilusionsoluctions.com.br em routes/callback.js
- [SINALIZADO] URLs de API ilusionsoluctions.com.br → substituídas por placeholders configuráveis

### DADOS
- [LIMPO] perms.json — IDs de usuários antigos removidos
- [LIMPO] clients.json — IDs de servidores clientes removidos
- [LIMPO] estatisticas.json — vendas antigas removidas
- [LIMPO] produtos.json — produtos de teste removidos
- [LIMPO] tickets.json, transcript.json — histórico antigo removido
- [LIMPO] configuracao.json — IDs de canais e cargos do servidor antigo removidos
- [LIMPO] configauth.json — credenciais OAuth antigas removidas

### DADOS PRESERVADOS (ESTRUTURA)
- Todos os schemas JSON mantidos (estrutura intacta para reusar)
- Toda lógica de negócio preservada
- Sistemas de pagamento preservados (sem credenciais — inserir novas)
- emojis.json preservado (IDs de emojis do Discord)

---

## Próximas versões planejadas
- [1.1.0] — Migração dos demais bots do pack Next Studio
- [1.2.0] — Painel redesenhado com Components V2 completo (NOXY Design System)
- [2.0.0] — NOXY como produto unificado com todos os módulos
