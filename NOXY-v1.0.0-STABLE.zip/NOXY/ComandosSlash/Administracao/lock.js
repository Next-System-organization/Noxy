const { PermissionFlagsBits } = require('discord.js');
const Discord = require("discord.js");
const { Emojis } = require("../../DataBaseJson");
const { getPermissions } = require("../../Functions/PermissionsCache.js");
const { container } = require("../../res.js");

module.exports = {
  name: "lock",
  description: "[🛠️ | Moderação] Trancar Chat",
  type: Discord.ApplicationCommandType.ChatInput,
  defaultMemberPermissions: [PermissionFlagsBits.ManageChannels],
  run: async (client, interaction) => {

    const perm = await getPermissions(client.user.id);
    if (!perm || !perm.includes(interaction.user.id)) {
      return interaction.reply({ content: `${Emojis.get('negative')} | Você não possui permissão para usar esse comando.`, ephemeral: true });
    }

    const containerContent = container("#2b2d31",
      { type: 10, content: `## 🔒 Canal Bloqueado` },
      { type: 14 },
      { type: 10, content: `> Este canal foi bloqueado por ${interaction.user}.\n> Apenas membros com permissão podem enviar mensagens.` },
      { type: 14 },
      {
        type: 1,
        components: [
          { type: 2, style: 2, label: 'Mensagem do Sistema', custom_id: 'msg_sistema_disabled', disabled: true },
          { type: 2, style: 2, label: 'Desbloquear', custom_id: 'Desbloquear1', emoji: { id: '1387981733273534596' } }
        ]
      }
    );

    await interaction.reply(containerContent);

    await interaction.channel.permissionOverwrites.edit(interaction.guild.id, { SendMessages: false })
      .catch(error => {
        console.error(error);
      });

    const collector = interaction.channel.createMessageComponentCollector();

    collector.on("collect", async (collectedInteraction) => {
      if (collectedInteraction.customId !== 'Desbloquear1') return;
      
      if (collectedInteraction.user.id !== interaction.user.id) {
        collectedInteraction.reply({ content: `${Emojis.get('negative')} | Você não tem permissão para destrancar esse canal.`, ephemeral: true });
      } else {
        await interaction.channel.permissionOverwrites.edit(interaction.guild.id, { SendMessages: true });

        const unlockContainer = container("#2b2d31",
          { type: 10, content: `## 🔓 Canal Desbloqueado` },
          { type: 14 },
          { type: 10, content: `> Este canal foi desbloqueado por ${interaction.user}.\n> Todos podem enviar mensagens novamente.` },
          { type: 14 },
          {
            type: 1,
            components: [
              { type: 2, style: 2, label: 'Mensagem do Sistema', custom_id: 'msg_sistema_disabled', disabled: true }
            ]
          }
        );

        collectedInteraction.update(unlockContainer);
        collector.stop();
      }
    });
  }
};