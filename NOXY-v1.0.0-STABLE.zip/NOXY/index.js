/**
 * NOXY — Next Studio
 * Desenvolvido por Ayann
 * NXY OS v1.0.0
 */

const {
    GatewayIntentBits,
    Client,
    Collection,
    EmbedBuilder,
    Partials,
    Events,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
} = require("discord.js");

const { AtivarIntents } = require("./Functions/StartIntents");
const { UploadEmojis } = require('./FunctionEmojis/EmojisFunction.js');
const { carregarCache } = require('./Handler/EmojiFunctions');
const express = require("express");
const { agendarRepostagem } = require('./Functions/repostagem');
const criarCanais = require('./Functions/CriarCanais.js');

const app = express();

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.DirectMessages,
    ],
    partials: [
        Partials.Channel,
        Partials.Message,
        Partials.User,
        Partials.GuildMember,
    ],
    sweepers: {
        messages: { interval: 300, lifetime: 600 },
        users: {
            interval: 3600,
            filter: () => user => user.bot && user.id !== client.user?.id,
        },
    },
});

// NXY_CORE — Estatísticas (exportado para uso interno)
const estatisticasNxyInstance = require("./Functions/VariaveisEstatisticas");
const EstatisticasNxy = new estatisticasNxyInstance();
module.exports = { EstatisticasNxy };

function getSaudacao() {
    const brazilTime = new Date().toLocaleString("en-US", { timeZone: "America/Sao_Paulo" });
    const hora = new Date(brazilTime).getHours();
    if (hora < 12) return "Bom dia";
    if (hora < 18) return "Boa tarde";
    return "Boa noite";
}

const config = require("./config.json");
const events = require("./Handler/events");
const slash = require("./Handler/slash");

// CRÍTICO: Collection deve ser definida ANTES de slash.run()
client.slashCommands = new Collection();

slash.run(client);
events.run(client);

process.on("unhandledRejection", () => {});
process.on("uncaughtException", () => {});
process.on("uncaughtExceptionMonitor", () => {});

// NXY_CORE — Rotas Express (OAuth)
const login = require("./routes/login");
app.use("/", login);
const callback = require("./routes/callback");
app.use("/", callback);

const PORT = process.env.PORT ? Number(process.env.PORT) : 8080;
app.listen(PORT, "0.0.0.0", () => {
    console.log(`\x1b[36m[NXY_CORE]\x1b[35m Servidor HTTP online na porta ${PORT}`);
});

// NXY_CORE — Evento ready
client.on("ready", async () => {
    console.log(`\x1b[36m[NOXY]\x1b[35m Online como ${client.user.tag}`);

    // Adicionar owner às permissões automaticamente
    try {
        const fs = require('fs');
        const permsPath = './DataBaseJson/perms.json';
        let permsData = {};
        if (fs.existsSync(permsPath)) {
            permsData = JSON.parse(fs.readFileSync(permsPath, 'utf8'));
        }
        const ownerId = config.owner;
        if (ownerId && ownerId !== "SEU_ID_DISCORD_AQUI" && !permsData[ownerId]) {
            permsData[ownerId] = ownerId;
            fs.writeFileSync(permsPath, JSON.stringify(permsData, null, 2));
            console.log(`\x1b[36m[NXY_CORE]\x1b[35m Owner (${ownerId}) adicionado às permissões.`);
        }
    } catch (err) {
        console.error('\x1b[31m[NXY_CORE]\x1b[0m Erro ao configurar owner:', err);
    }

    // Status do bot
    const activities = [{ name: `NOXY · Next Studio`, type: 1, url: "https://www.twitch.tv/discord" }];
    let i = 0;
    setInterval(() => {
        if (i >= activities.length) i = 0;
        client.user.setActivity(activities[i]);
        i++;
    }, 60 * 1000);

    // Carregar emojis
    await UploadEmojis(client)
        .then(() => console.log('\x1b[36m[NXY_CORE]\x1b[35m Emojis carregados.'))
        .catch(err => console.error('\x1b[31m[NXY_CORE]\x1b[0m Erro ao carregar emojis:', err));

    console.log(`\x1b[36m[NXY_CORE]\x1b[35m ${client.user.tag} → ${client.guilds.cache.size} servidor(es), ${client.channels.cache.size} canais`);
    carregarCache();
});

// NXY_CORE — Mencionar o bot
client.on(Events.MessageCreate, async (message) => {
    if (message.author.bot) return;

    try {
        const { ProcessarSugestao } = require("./Functions/SistemaSugestoes.js");
        await ProcessarSugestao(message, client);
    } catch (_) {}

    if (message.mentions.has(client.user)) {
        const embed = new EmbedBuilder()
            .setColor("#000000")
            .setDescription(`**NOXY** · Bot exclusivo do servidor \`${message.guild?.name ?? "Discord"}\`\nVersão **NXY OS** \`1.0.0\`\nDesenvolvido pela **Next Studio**`);

        const reply = await message.channel.send({ embeds: [embed] });
        setTimeout(() => reply.delete().catch(() => {}), 10_000);
    }
});

// NXY_CORE — Criação de canais automáticos
client.on("interactionCreate", async (interaction) => {
    if (!interaction.isButton()) return;

    if (interaction.customId === "criarcanaisfds") {
        const embed = new EmbedBuilder()
            .setDescription(`-# Olá ${interaction.user}, este comando criará uma categoria e configurará os canais automaticamente. Deseja continuar?`)
            .setColor("#2F3136");

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("confirmarCriacao").setLabel("Confirmar").setStyle(3),
            new ButtonBuilder().setCustomId("cancelarCriacao").setLabel("Cancelar").setStyle(ButtonStyle.Danger)
        );
        return interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
    }

    if (interaction.customId === "confirmarCriacao") {
        criarCanais.criarCanais(interaction);
    }

    if (interaction.customId === "cancelarCriacao") {
        return interaction.update({ content: '× Criação cancelada.', embeds: [], components: [] });
    }
});

// NXY_CORE — Modal editar mensagem de boas vindas
client.on("interactionCreate", async (interaction) => {
    if (!interaction.isButton()) return;

    if (interaction.customId === "editarmensagemboasvindas") {
        const modal = new ModalBuilder()
            .setCustomId("sdaju111idsjjsdua")
            .setTitle("Editar Boas Vindas");

        const inputMsg = new TextInputBuilder()
            .setCustomId("tokenMP")
            .setLabel("Mensagem")
            .setPlaceholder("Use {member} para mencionar o membro e {guildname} para o servidor.")
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true)
            .setMaxLength(1000);

        const inputTempo = new TextInputBuilder()
            .setCustomId("tokenMP2")
            .setLabel("Tempo para apagar (segundos)")
            .setPlaceholder("Insira a quantidade em segundos.")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setMaxLength(6);

        const inputCanal = new TextInputBuilder()
            .setCustomId("qualcanal")
            .setLabel("Qual canal enviar? (ID)")
            .setPlaceholder("Insira o ID do canal. (ID, ID, ID)")
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(false);

        modal.addComponents(
            new ActionRowBuilder().addComponents(inputMsg),
            new ActionRowBuilder().addComponents(inputTempo),
            new ActionRowBuilder().addComponents(inputCanal)
        );

        await interaction.showModal(modal);
    }
});

client.login(config.token);
