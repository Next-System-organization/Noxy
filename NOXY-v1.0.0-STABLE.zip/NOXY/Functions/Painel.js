const { ActionRowBuilder, ButtonBuilder, StringSelectMenuBuilder } = require("discord.js");
const { produtos, configuracao } = require("../DataBaseJson");
const { res } = require("../res");
const startTime = Date.now();
const emojis = require("../DataBaseJson/emojis.json");

const Emojis = {
    get: (name) => emojis[name] || ""
};

function getSaudacao() {
  const brazilTime = new Date().toLocaleString("en-US", {timeZone: "America/Sao_Paulo"});
  const hora = new Date(brazilTime).getHours();

  if (hora < 12) {
      return 'Bom dia';
  } else if (hora < 18) {
      return 'Boa tarde';
  } else {
      return 'Boa noite';
  }
}

async function Painel(interaction, client) {

  const row2 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId("painelconfigvendas")
        .setLabel('Sistema Vendas')
        .setEmoji(`<:cesta:1456162138526847069>`)
        .setStyle(2)
        .setDisabled(false),

      new ButtonBuilder()
        .setCustomId("painelconfigticket")
        .setLabel('Sistema Ticket')
        .setEmoji(`${Emojis.get('ticketpanel')}`)
        .setStyle(2)
        .setDisabled(false),

      new ButtonBuilder()
        .setCustomId("painelconfigbv")
        .setLabel('Boas Vindas')
        .setEmoji(`<:welcome:1456162105823596604>`)
        .setStyle(2)
        .setDisabled(false),

      new ButtonBuilder()
        .setCustomId("eaffaawwawa")
        .setLabel('Ações Automaticas')
        .setEmoji(`<:menu:1455381263560212593>`)
        .setStyle(2)
        .setDisabled(false),
    )

  const row3 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId("painelpersonalizar")
        .setLabel('Personalizar Bot')
        .setEmoji(`<:sentiment_very_satisfied_24dp_E3:1456171505821024266>`)
        .setStyle(2)
        .setDisabled(false),
      
      new ButtonBuilder()
        .setCustomId("sistemaauth")
        .setLabel('NXY Cloud')
        .setEmoji(`<:ecloudemoj:1455380851490820138>`)
        .setStyle(2)
        .setDisabled(false),
      
      new ButtonBuilder()
        .setCustomId("rendimento")
        .setLabel('Rendimentos')
        .setEmoji(`<:rendimentos:1455380926661005424>`)
        .setStyle(2)
        .setDisabled(false),

      new ButtonBuilder()
        .setCustomId("gerenciarconfigs")
        .setLabel('Configurações Gerais')
        .setEmoji(`${Emojis.get('_settings_emoji')}`)
        .setStyle(2)
        .setDisabled(false)
    )

  const row9 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setLabel('Sistema de Sorteios')
        .setStyle(2)
        .setCustomId('sistemasorteios')
        .setDisabled(false)
        .setEmoji("<:presentes:1456162063255601162>"),
      new ButtonBuilder()
        .setLabel('NXY Bux')
        .setStyle(2)
        .setCustomId('painelconfigrobux')
        .setDisabled(false)
        .setEmoji("1350550813898178570")
    )

  const containerContent = res.main(
     { type: 10, content: `-# NOXY · Next Studio — Painel Principal` },
    { type: 14 },
    { type: 10, content: `-# - **Olá ${interaction.user} seja bem vindo ao painel principal do seu bot, utilize os botões abaixo para configurar sua aplicação**` },
    { type: 14 },
    { type: 10, content: `> ${Emojis.get('epro')} **NXY OS:** \`1.0.0\`\n> ${Emojis.get('antena')} **Ping:** \`${client.ws.ping} ms\`\n> ${Emojis.get('relogio')} **Uptime:** <t:${Math.ceil(startTime / 1000)}:R>` }
  ).with({
    components: [row2, row3, row9],
    flags: [64]
  });

  if (interaction.message == undefined) {
    interaction.reply(containerContent)
  } else {
    interaction.update(containerContent)
  }
}

async function Gerenciar2(interaction, client) {

  const ggg = produtos.valueArray();

  const rowVoltar = new ActionRowBuilder()
    .addComponents( 
      new ButtonBuilder()
        .setCustomId("voltar00")
        .setLabel('Voltar')
        .setEmoji(`1178068047202893869`)
        .setStyle(2)
    )

  const containerContent = res.main(
    { type: 10, content: `-# Painel > Sistema de Vendas` },
    { type: 14 },
    { type: 10, content: `${getSaudacao()} Senhor(a) **${interaction.user.username}**, aqui você pode configurar e gerenciar todos os produtos de sua loja!` },
    { type: 14 },
    { type: 10, content: `> ${Emojis.get('caixagrande')} **Produtos Criados:** \`${ggg.length}\`` },
    { type: 14 },
    {
      type: 1,
      components: [{
        type: 3,
        custom_id: "gerenciar_produtos_menu",
        placeholder: "Selecione uma opção",
        options: [
          {
            label: "Criar Produto",
            description: "Criar um novo produto na loja",
            value: "criarrrr",
            emoji: { id: "1178067873894236311" }
          },
          {
            label: "Gerenciar Produtos",
            description: "Gerenciar produtos existentes",
            value: "gerenciarotemae",
            emoji: { id: "1178067945855910078" }
          },
          {
            label: "Cargos Rank",
            description: "Configurar cargos de ranking",
            value: "gerenciarposicao",
            emoji: { id: "1178086608004722689" }
          },
          {
            label: "Painel de Solicitar Stock",
            description: "Configurar painel de solicitação de estoque",
            value: "painel-solicitar-stock",
            emoji: { id: "1459316241490776197" }
          },
          {
            label: "Sistema de Saldo",
            description: "Em desenvolvimento",
            value: "sistemasaldo",
            emoji: { id: "1459050684824682517" }
          },
          {
            label: "Sistema de Afiliado",
            description: "Em desenvolvimento",
            value: "sistemaafiliado",
            emoji: { id: "1459050649244401745" }
          }
        ]
      }]
    }
  ).with({
    components: [rowVoltar],
    flags: [64]
  });

  await interaction.update(containerContent)
}

async function PainelExtensoes(interaction, client) {
  const { res } = require("../res");
  const rowVoltar = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("voltar00").setLabel("Voltar").setEmoji("1178068047202893869").setStyle(2)
  );
  const msg = res.main(
    { type: 10, content: `-# Painel > Extensões` },
    { type: 14 },
    { type: 10, content: `> Esta seção está em desenvolvimento.\n> Novas extensões serão adicionadas em breve.` }
  ).with({ components: [rowVoltar], flags: [64] });
  await interaction.update(msg);
}

module.exports = {
  Painel,
  Gerenciar2,
  PainelExtensoes
}
