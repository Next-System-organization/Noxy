const { ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { configuracao, Emojis } = require("../DataBaseJson");
const { res } = require("../res");

function getEmojiObject(emojiStr) {
    if (!emojiStr || emojiStr === "") return { name: "⚙️" };
    if (/^\d+$/.test(emojiStr)) return { id: emojiStr };
    const match = emojiStr.match(/<a?:\w+:(\d+)>/);
    if (match) return { id: match[1] };
    return { name: emojiStr };
}

async function automatico(interaction, client) {
    const rowVoltar = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("voltar1")
            .setEmoji(`${Emojis.get('_back_emoji')}`)
            .setLabel('Voltar')
            .setStyle(2)
    );

    const containerContent = res.main(
        { type: 10, content: `-# Painel > Ações Automáticas` },
        { type: 14 },
        { type: 10, content: `**Sistemas Automáticos**\n> Configure funcionalidades inteligentes que tornarão seu bot mais eficiente.` },
        { type: 14 },
        { type: 10, content: `**Opções Disponíveis**\n>  **Repostagem Automática** - Republique produtos automaticamente\n>  **Configurar Mensagens Automáticas** - Envie mensagens em intervalos\n>  **Lock Automático** - Bloqueie/desbloqueie canais por horário\n>  **Monitorador de Feedbacks** - Monitore avaliações *(Em desenvolvimento)*` },
        { type: 14 },
        {
            type: 1,
            components: [{
                type: 3,
                custom_id: "select_acoes_automaticas",
                placeholder: "Selecione uma ação automática",
                options: [
                    {
                        label: "Repostagem Automática",
                        value: "automaticRepostar",
                        description: "Republique produtos automaticamente",
                        emoji: { id: "1384035219874779147" }
                    },
                    {
                        label: "Configurar Mensagens Automáticas",
                        value: "configMensagensAuto",
                        description: "Envie mensagens em intervalos",
                        emoji: { id: "1459059825483714665" }
                    },
                    {
                        label: "Lock Automático",
                        value: "configlock",
                        description: "Bloqueie/desbloqueie canais por horário",
                        emoji: { id: "1459059758353879093" }
                    },
                    {
                        label: "Monitorador de Feedbacks",
                        value: "monitorfeedbacks",
                        description: "Em desenvolvimento",
                        emoji: { id: "1459059777916243969" }
                    },
                    {
                        label: "Sistema de Sugestões",
                        value: "sistemasugestoes",
                        description: "Configure o sistema de sugestões",
                        emoji: { id: "1442998912347672687" }
                    }
                ]
            }]
        }
    ).with({
        components: [rowVoltar],
        flags: [64]
    });

    await interaction.update(containerContent);
}

module.exports = {
    automatico
};
