const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { configuracao } = require("../DataBaseJson");
const { JsonDatabase } = require("wio.db");
const axios = require("axios");
const emojis = require("../DataBaseJson/emojis.json");

const Emojis = {
    get: (name) => emojis[name] || ""
};

const robuxConfig = new JsonDatabase({
    databasePath: "./DataBaseJson/configuracaorobux.json"
});

const carrinhosRobux = new JsonDatabase({
    databasePath: "./DataBaseJson/carrinhosrobux.json"
});

const pagamentosRobux = new JsonDatabase({
    databasePath: "./DataBaseJson/pagamentosrobux.json"
});

const pedidosRobux = new JsonDatabase({
    databasePath: "./DataBaseJson/pedidosrobux.json"
});

async function VerificarPagamentoRobux(client) {
    const allPayments = pagamentosRobux.fetchAll();

    for (const payment of allPayments) {
        const method = payment.data.pagamento.method;
        const paymentDate = payment.data.pagamento.data;
        const carrinho = payment.data.carrinho;

        let threadChannel;
        try {
            threadChannel = await client.channels.fetch(payment.ID);

            
            const tenMinutesLater = paymentDate + 10 * 60 * 1000;

            if (Date.now() > tenMinutesLater) {
                
                await threadChannel.delete().catch(() => {});
                pagamentosRobux.delete(payment.ID);
                carrinhosRobux.delete(payment.data.oderId);

                
                try {
                    const canalLog = robuxConfig.get('config.canais.canceladas');
                    if (canalLog) {
                        const canal = await client.channels.fetch(canalLog);
                        const embedExp = new EmbedBuilder()
                            .setColor(configuracao.get(`Cores.Erro`) || '#ff0000')
                            .setAuthor({ name: `Pagamento Expirado` })
                            .setDescription(`${Emojis.get('negative') || '❌'} Usuário <@${payment.data.oderId}> deixou o pagamento expirar.`)
                            .addFields(
                                { name: `**Detalhes**`, value: `\`${carrinho.robuxFinal} Robux - ${carrinho.gamepassSelecionado?.name || 'N/A'} | R$ ${carrinho.valorFinal}\`` }
                            )
                            .setTimestamp();
                        
                        if (carrinho.robloxUser?.avatar) {
                            embedExp.setThumbnail(carrinho.robloxUser.avatar);
                        }
                        
                        await canal.send({ embeds: [embedExp] });
                    }
                } catch (e) {}
                continue;
            }

        } catch (error) {
            console.error(`[Robux] Erro ao processar pagamento ${payment.ID}:`, error.message);
            pagamentosRobux.delete(payment.ID);
            carrinhosRobux.delete(payment.data.oderId);
            continue;
        }

        
        if (method === 'mercadopago') {
            await verificarMercadoPago(client, payment, threadChannel);
        } else if (method === 'efibank') {
            await verificarEfiBank(client, payment, threadChannel);
        } else if (method === 'misticpay') {
            await verificarMisticPay(client, payment, threadChannel);
        }
    }
}


async function verificarMercadoPago(client, payment, threadChannel) {
    try {
        const mpToken = configuracao.get('pagamentos.MpAPI');
        const res = await axios.get(`https://api.mercadopago.com/v1/payments/${payment.data.pagamento.id}`, {
            headers: { Authorization: `Bearer ${mpToken}` }
        });

        if (res?.data.status === 'approved') {
            await aprovarPagamentoRobux(client, payment, threadChannel, 'Mercado Pago');
        }
    } catch (error) {
        
    }
}


async function verificarEfiBank(client, payment, threadChannel) {
    try {
        const fs = require('fs');
        const https = require('https');

        let certificado = fs.readFileSync(`./Lib/${configuracao.get("pagamentos.certificado")}.p12`);
        const httpsAgent = new https.Agent({ pfx: certificado, passphrase: "" });

        var data = JSON.stringify({ grant_type: "client_credentials" });
        var data_credentials = configuracao.get(`pagamentos.secret_id`) + ":" + configuracao.get(`pagamentos.secret_token`);
        var auth = Buffer.from(data_credentials).toString("base64");

        var config = {
            method: "POST",
            url: "https://pix.api.efipay.com.br/oauth/token",
            headers: { Authorization: "Basic " + auth, "Content-Type": "application/json" },
            httpsAgent: httpsAgent,
            data: data,
        };

        let access_token = await axios(config).then(r => r.data.access_token);

        var configCheck = {
            method: "get",
            url: `https://pix.api.efipay.com.br/v2/cob/${payment.data.pagamento.id}`,
            headers: { Authorization: `Bearer ${access_token}`, "Content-Type": "application/json" },
            httpsAgent: httpsAgent,
        };

        let res = await axios(configCheck).then(r => r.data);

        if (res.status === 'CONCLUIDA') {
            await aprovarPagamentoRobux(client, payment, threadChannel, 'EfiBank');
        }
    } catch (error) {
        
    }
}


async function verificarMisticPay(client, payment, threadChannel) {
    try {
        const clientId = configuracao.get('pagamentos.mistclientid');
        const clientSecret = configuracao.get('pagamentos.misticsecret');

        const res = await axios.post('https://api.misticpay.com/api/transactions/check', {
            transactionId: payment.data.pagamento.id
        }, {
            headers: { 'ci': clientId, 'cs': clientSecret, 'Content-Type': 'application/json' },
            timeout: 5000
        });

        if (res?.data?.transaction?.transactionState === 'COMPLETO') {
            await aprovarPagamentoRobux(client, payment, threadChannel, 'MisticPay');
        }
    } catch (error) {
        
    }
}



async function aprovarPagamentoRobux(client, payment, threadChannel, banco) {
    const carrinho = payment.data.carrinho;
    const oderId = payment.data.oderId;

    
    pagamentosRobux.delete(payment.ID);

    
    pedidosRobux.set(payment.ID, {
        oderId: oderId,
        visão: payment.data.pagamento,
        carrinho: carrinho,
        banco: banco,
        aprovadoEm: Date.now()
    });

    try {
        
        const messages = await threadChannel.messages.fetch({ limit: 100 });
        for (const msg of messages.values()) {
            await msg.delete().catch(() => {});
        }
    } catch (e) {}

    
    const perfilRobloxLink = `https://www.roblox.com/users/${carrinho.robloxUser?.id}/profile`;
    const gamepassLink = `https://www.roblox.com/game-pass/${carrinho.gamepassSelecionado?.id}`;

    
    const embedAprovado = new EmbedBuilder()
        .setColor(configuracao.get(`Cores.Sucesso`) || '#2ecc71')
        .setAuthor({ name: `Pedido Aprovado`, iconURL: `https://images-ext-1.discordapp.net/external/CjyTPdl-laCV1ZOHeYVVHvqcGAyZL70PEVz9MRkQEqI/%3Fsize%3D2048/https/cdn.discordapp.com/emojis/1249486723520397314.png?format=webp&quality=lossless` })
        .setDescription(`${Emojis.get('completedcart_emoji') || '✅'} O pagamento foi confirmado com sucesso!\n\nAgora é necessário **comprar o GamePass** do cliente para entregar os Robux.`)
        .addFields(
            { name: `**Detalhes**`, value: `\`${carrinho.robuxFinal} Robux - ${carrinho.gamepassSelecionado?.name || 'N/A'} | R$ ${carrinho.valorFinal}\`` }
        )
        .addFields(
            { name: '👤 Cliente Discord', value: `<@${oderId}>`, inline: true },
            { name: '🎮 Cliente Roblox', value: `\`${carrinho.robloxUser?.name || 'N/A'}\``, inline: true },
            { name: '🏦 Método', value: `\`Pix - ${banco}\``, inline: true }
        )
        .setFooter({ text: 'Clique nos botões abaixo para acessar o perfil e o GamePass' })
        .setTimestamp();

    if (carrinho.robloxUser?.avatar) {
        embedAprovado.setThumbnail(carrinho.robloxUser.avatar);
    }

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setLabel('Perfil do Usuário')
            .setURL(perfilRobloxLink)
            .setEmoji('👤')
            .setStyle(5),
        new ButtonBuilder()
            .setLabel('GamePass')
            .setURL(gamepassLink)
            .setEmoji('🎫')
            .setStyle(5),
        new ButtonBuilder()
            .setCustomId(`robux_entrega_concluida_${payment.ID}`)
            .setLabel('Entrega Concluída')
            .setEmoji(Emojis.get('checker') || '✅')
            .setStyle(3)
    );

    await threadChannel.send({ 
        content: `<@${oderId}>`,
        embeds: [embedAprovado], 
        components: [row] 
    });

    
    try {
        await threadChannel.setName(`✅・${carrinho.robloxUser?.name || 'user'}・robux`);
    } catch (e) {}

    
    try {
        const user = await client.users.fetch(oderId);
        const embedDM = new EmbedBuilder()
            .setColor(configuracao.get(`Cores.Sucesso`) || '#2ecc71')
            .setAuthor({ name: `Pedido Aprovado`, iconURL: `https://images-ext-1.discordapp.net/external/CjyTPdl-laCV1ZOHeYVVHvqcGAyZL70PEVz9MRkQEqI/%3Fsize%3D2048/https/cdn.discordapp.com/emojis/1249486723520397314.png?format=webp&quality=lossless` })
            .setDescription(`${Emojis.get('completedcart_emoji') || '✅'} Seu pagamento de **R$ ${carrinho.valorFinal}** foi aprovado!\n\nAguarde a entrega dos seus **${carrinho.robuxFinal} Robux**.`)
            .addFields(
                { name: `**Detalhes**`, value: `\`${carrinho.robuxFinal} Robux - ${carrinho.gamepassSelecionado?.name || 'N/A'} | R$ ${carrinho.valorFinal}\`` },
                { name: `**Forma de Pagamento**`, value: `\`Pix - ${banco}\`` }
            )
            .setTimestamp();

        await user.send({ embeds: [embedDM] }).catch(() => {});
    } catch (e) {}

    
    try {
        const canalLog = robuxConfig.get('config.canais.iniciadas');
        if (canalLog) {
            const canal = await client.channels.fetch(canalLog);
            const embedLog = new EmbedBuilder()
                .setColor(configuracao.get(`Cores.Processamento`) || '#f1c40f')
                .setAuthor({ name: `Pedido Aprovado - Aguardando Entrega` })
                .setDescription(`${Emojis.get('completedcart_emoji') || '✅'} Usuário <@${oderId}> teve o pagamento aprovado e está aguardando entrega.`)
                .addFields(
                    { name: `**Detalhes**`, value: `\`${carrinho.robuxFinal} Robux - ${carrinho.gamepassSelecionado?.name || 'N/A'} | R$ ${carrinho.valorFinal}\`` },
                    { name: `**ID do Pedido**`, value: `\`${payment.ID}\`` },
                    { name: `**Forma de pagamento**`, value: `\`Pix - ${banco}\`` }
                )
                .setFooter({ text: threadChannel.guild?.name || 'Servidor' })
                .setTimestamp();

            if (carrinho.robloxUser?.avatar) {
                embedLog.setThumbnail(carrinho.robloxUser.avatar);
            }

            await canal.send({ embeds: [embedLog] });
        }
    } catch (e) {}
}


async function confirmarEntregaRobux(interaction, pedidoId, client) {
    
    if (!interaction.member.permissions.has('Administrator')) {
        return interaction.reply({
            content: `${Emojis.get('negative') || '❌'} | Apenas **administradores** podem confirmar a entrega!`,
            ephemeral: true
        });
    }

    const pedido = pedidosRobux.get(pedidoId);
    
    if (!pedido) {
        return interaction.reply({
            content: `${Emojis.get('negative') || '❌'} | Pedido não encontrado!`,
            ephemeral: true
        });
    }

    const carrinho = pedido.carrinho;
    const guild = interaction.guild;

    
    pedido.entregue = true;
    pedido.entregueEm = Date.now();
    pedido.entreguePor = interaction.user.id;
    pedidosRobux.set(pedidoId, pedido);

    
    carrinhosRobux.delete(pedido.oderId);

    
    const embedFinal = new EmbedBuilder()
        .setColor(configuracao.get(`Cores.Sucesso`) || '#2ecc71')
        .setAuthor({ name: `Pedido #${pedidoId}`, iconURL: `https://images-ext-1.discordapp.net/external/CjyTPdl-laCV1ZOHeYVVHvqcGAyZL70PEVz9MRkQEqI/%3Fsize%3D2048/https/cdn.discordapp.com/emojis/1249486723520397314.png?format=webp&quality=lossless` })
        .setDescription(`${Emojis.get('completedcart_emoji') || '🎉'} Os Robux foram entregues com sucesso!\n\nEste canal será deletado em **10 segundos**.`)
        .addFields(
            { name: `**Detalhes**`, value: `\`${carrinho.robuxFinal} Robux - ${carrinho.gamepassSelecionado?.name || 'N/A'} | R$ ${carrinho.valorFinal}\`` }
        )
        .setFooter({ text: guild.name, iconURL: guild.iconURL({ dynamic: true }) })
        .setTimestamp();

    await interaction.update({ embeds: [embedFinal], components: [] });

    
    try {
        const user = await client.users.fetch(pedido.oderId);
        const embedDM = new EmbedBuilder()
            .setColor(configuracao.get(`Cores.Sucesso`) || '#2ecc71')
            .setAuthor({ name: `Pedido #${pedidoId}`, iconURL: `https://images-ext-1.discordapp.net/external/CjyTPdl-laCV1ZOHeYVVHvqcGAyZL70PEVz9MRkQEqI/%3Fsize%3D2048/https/cdn.discordapp.com/emojis/1249486723520397314.png?format=webp&quality=lossless` })
        .setDescription(`${Emojis.get('completedcart_emoji') || '🎉'} Seus **${carrinho.robuxFinal} Robux** foram entregues com sucesso!\n\nObrigado por comprar conosco!`)
            .addFields(
                { name: `**Detalhes**`, value: `\`${carrinho.robuxFinal} Robux - ${carrinho.gamepassSelecionado?.name || 'N/A'} | R$ ${carrinho.valorFinal}\`` }
            )
            .setFooter({ text: guild.name, iconURL: guild.iconURL({ dynamic: true }) })
            .setTimestamp();

        await user.send({ embeds: [embedDM] }).catch(() => {});
    } catch (e) {}

    
    try {
        const canalAprovadas = robuxConfig.get('config.canais.aprovadas');
        if (canalAprovadas) {
            const canal = await client.channels.fetch(canalAprovadas);
            const embedLog = new EmbedBuilder()
                .setColor(configuracao.get(`Cores.Sucesso`) || '#2ecc71')
                .setAuthor({ name: `Pedido #${pedidoId}`, iconURL: `https://images-ext-1.discordapp.net/external/CjyTPdl-laCV1ZOHeYVVHvqcGAyZL70PEVz9MRkQEqI/%3Fsize%3D2048/https/cdn.discordapp.com/emojis/1249486723520397314.png?format=webp&quality=lossless` })
                .setDescription(`${Emojis.get('completedcart_emoji') || '✅'} Usuário <@${pedido.oderId}> teve seu pedido de Robux entregue.`)
                .addFields(
                    { name: `**Detalhes**`, value: `\`${carrinho.robuxFinal} Robux - ${carrinho.gamepassSelecionado?.name || 'N/A'} | R$ ${carrinho.valorFinal}\`` },
                    { name: `**Roblox**`, value: `\`${carrinho.robloxUser?.name || 'N/A'}\``, inline: true },
                    { name: `**Entregue por**`, value: `<@${interaction.user.id}>`, inline: true }
                )
                .setFooter({ text: guild.name, iconURL: guild.iconURL({ dynamic: true }) })
                .setTimestamp();

            if (carrinho.robloxUser?.avatar) {
                embedLog.setThumbnail(carrinho.robloxUser.avatar);
            }

            await canal.send({ embeds: [embedLog] });
        }
    } catch (e) {
        console.error('[Robux] Erro ao enviar log de aprovação:', e);
    }

    
    try {
        const canalEventos = configuracao.get(`ConfigChannels.eventbuy`);
        if (canalEventos) {
            const canalPublico = await client.channels.fetch(canalEventos);
            
            const embedPublico = new EmbedBuilder()
                .setColor(configuracao.get(`Cores.Sucesso`) || '#2ecc71')
                .setAuthor({ name: `Compra Aprovada`, iconURL: `https://images-ext-1.discordapp.net/external/_4RFG9_wx9GMsiOlXivLlAwB5MfEHKQbD07bxwrd6lQ/%3Fsize%3D2048/https/cdn.discordapp.com/emojis/1249486366329409637.png?format=webp&quality=lossless` })
                .setThumbnail(guild.iconURL({ dynamic: true }))
                .setDescription(`${Emojis.get('neworder_emoji') || '🛒'} O usuário <@${pedido.oderId}> realizou uma compra de Robux no servidor`)
                .addFields(
                    { name: `**Carrinho**`, value: `\`${carrinho.robuxFinal} Robux - ${carrinho.gamepassSelecionado?.name || 'N/A'}\`` },
                    { name: `**Valor pago**`, value: `\`R$ ${carrinho.valorFinal}\`` }
                )
                .setFooter({ text: guild.name, iconURL: guild.iconURL({ dynamic: true }) })
                .setTimestamp();

            await canalPublico.send({ embeds: [embedPublico] });
        }
    } catch (e) {
        console.error('[Robux] Erro ao enviar log público:', e);
    }

    
    setTimeout(async () => {
        try {
            await interaction.channel.delete();
        } catch (e) {}
    }, 10000);
}

module.exports = {
    VerificarPagamentoRobux,
    aprovarPagamentoRobux,
    confirmarEntregaRobux,
    pedidosRobux
}
