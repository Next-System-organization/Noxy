const fs = require("fs");
const path = require("path");
const PERMS_PATH = path.resolve(__dirname, "../DataBaseJson/perms.json");

async function getPermissions() {
    try {
        const raw = fs.readFileSync(PERMS_PATH, "utf8");
        const idAdmin = JSON.parse(raw);
        return Object.values(idAdmin);
    } catch (_) {
        return [];
    }
}

module.exports = { getPermissions };
